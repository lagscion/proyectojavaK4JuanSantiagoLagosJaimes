package com.mycompany.proyectok4juanllgos.persistencia;

import java.sql.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class ConexionBD {
    private ConexionBD(){}
    public static Connection obtener() throws SQLException {
        Properties p=new Properties();
        try(InputStream in=ConexionBD.class.getClassLoader().getResourceAsStream("db.properties")){
            if(in!=null)p.load(in);
        }catch(IOException e){throw new SQLException("No se pudo leer db.properties",e);}
        String url=p.getProperty("db.url",System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/crediya_db"));
        String user=p.getProperty("db.user",System.getenv().getOrDefault("DB_USER","root"));
        String pass=p.getProperty("db.password",System.getenv().getOrDefault("DB_PASSWORD",""));
        return DriverManager.getConnection(url,user,pass);
    }
}
