package main;

import com.mycompany.proyectok4juanllgos.modelo.clientes;
import com.mycompany.proyectok4juanllgos.modelo.empleados;
import com.mycompany.proyectok4juanllgos.modelo.prestamos;
import com.mycompany.proyectok4juanllgos.persistencia.dbConnection;
import com.mycompany.proyectok4juanllgos.controlador.ingreso;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        dbConnection dbc = new dbConnection();
        ingreso authService = new ingreso();
        Scanner sc = new Scanner(System.in);

        try (Connection conexion = dbc.conectar()) {
            if (conexion == null) {
                System.out.println("No se pudo establecer la conexión con la base de datos.");
                return;
            }

            boolean aplicacionActiva = true;

            while (aplicacionActiva) {
                boolean sesionIniciada = false;
                String rolUsuario = null;
                boolean permisoModificacion = false;
                int usuarioId = 0;                                   // NUEVO
                String usuarioActual = "";

                System.out.println("\n=== BIENVENIDO AL SISTEMA ===");

                while (!sesionIniciada) {
                    System.out.print("\nUsuario: ");
                    usuarioActual = sc.nextLine();

                    System.out.print("Password: ");
                    String pss = sc.nextLine();

                    ingreso.Sesion sesion = authService.autenticar(conexion, usuarioActual, pss);

                    if (sesion != null) {
                        rolUsuario = sesion.rol;
                        permisoModificacion = sesion.permisoModificacion;
                        usuarioId = sesion.id;                       // NUEVO
                        sesionIniciada = true;
                        System.out.println("\n¡Acceso concedido! Bienvenid@, " + usuarioActual + " (" + rolUsuario + ").");
                    } else {
                        System.out.println("Acceso denegado. Usuario o contraseña incorrectos. Intente de nuevo.");
                    }
                }

                // CAMBIO: se pasa también usuarioId
                boolean cerrarSesion = ejecutarMenuPrincipal(sc, rolUsuario, usuarioActual, permisoModificacion, usuarioId);

                if (!cerrarSesion) {
                    aplicacionActiva = false;
                }
            }

        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // CAMBIO: nuevo parámetro usuarioId
    private static boolean ejecutarMenuPrincipal(Scanner sc, String rol, String usuario,
                                                 boolean permisoModificacion, int usuarioId) throws SQLException {
        boolean salirAlLogin = false;

        while (!salirAlLogin) {
            System.out.println("\n--- MENÚ PRINCIPAL (" + rol.toUpperCase() + ") ---");

            if (rol.equalsIgnoreCase("empleado")) {

                System.out.println("1. Registrar empleado");
                System.out.println("2. Consultar empleado");
                System.out.println("3. Consultar préstamos relacionados");   // NUEVO

                String opcionSalir;
                if (permisoModificacion) {
                    System.out.println("4. Actualizar empleado");
                    System.out.println("5. Eliminar empleado");
                    System.out.println("6. crear prestamo");
                    System.out.println("7. Cambiar estado de prestamo");
                    System.out.println("8. abonar aprestamos");
                    System.out.println("9. historico de pagos");
                    System.out.println("10. historial de pagos");
                    System.out.println("11. Cerrar sesión");
                    opcionSalir = "11";
                } else {
                    System.out.println("4. Cerrar sesión");
                    opcionSalir = "4";
                }

                System.out.print("Seleccione una opción: ");
                String opcion = sc.nextLine().trim();

                if (opcion.equals("1")) {
                    empleados.registrarEmpleado();
                } else if (opcion.equals("2")) {
                    empleados.consultarEmpleado();
                } else if (opcion.equals("3")) {
                    prestamos.consultarPrestamosEmpleado(usuarioId);     
                } else if (opcion.equals("4") && permisoModificacion) {
                    empleados.actualizarEmpleado();
                } else if (opcion.equals("5") && permisoModificacion) {
                    empleados.eliminarEmpleado();
               } else if(opcion.equals("6")&& permisoModificacion){
                   empleados.crearPrestamo(usuarioId);
               }else if (opcion.equals("7") && permisoModificacion) {
                   empleados.cambiarEstado();
               }else if (opcion.equals("8")&& permisoModificacion){
                   empleados.abonos();
               }else if(opcion.equals("9")&& permisoModificacion){
                   empleados.mostrarHistoricoPagos();
               }else if (opcion.equals("10")&& permisoModificacion){
                       empleados.consultarReportesPrestamos();
                       }
                   else if (opcion.equals(opcionSalir)) {
                    salirAlLogin = true;
                    System.out.println("Cerrando sesión. Volviendo al inicio de sesión...");
                } else {
                    System.out.println("Opción no válida.");
                }

            } else {

                System.out.println("1. Registrar cliente");
                System.out.println("2. Listar clientes");
                System.out.println("3. Consultar préstamos relacionados");   // NUEVO

                String opcionSalir;
                if (permisoModificacion) {
                    System.out.println("4. Actualizar cliente");
                    System.out.println("5. Eliminar cliente");
                    System.out.println("6. Cerrar sesión");
                    opcionSalir = "6";
                } else {
                    System.out.println("4. Cerrar sesión");
                    opcionSalir = "4";
                }

                System.out.print("Seleccione una opción: ");
                String opcion = sc.nextLine().trim();

                if (opcion.equals("1")) {
                    clientes.registrarCliente();
                } else if (opcion.equals("2")) {
                    clientes.listarClientes();
                } else if (opcion.equals("3")) {
                    prestamos.consultarPrestamosCliente(usuarioId);      // NUEVO
                } else if (opcion.equals("4") && permisoModificacion) {
                    clientes.actualizarCliente();
                } else if (opcion.equals("5") && permisoModificacion) {
                    clientes.eliminarCliente();
                } else if (opcion.equals(opcionSalir)) {
                    salirAlLogin = true;
                    System.out.println("Cerrando sesión. Volviendo al inicio de sesión...");
                } else {
                    System.out.println("Opción no válida.");
                }
            }
        }

        return true;
    }
}