package com.mycompany.proyectok4juanllgos.modelo;

import com.mycompany.proyectok4juanllgos.persistencia.dbConnection;

import static com.mycompany.proyectok4juanllgos.modelo.prestamos.listar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class clientes {

    public static void registrarCliente() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE LOS SIGUIENTES DATOS ===");

        while (true) {
            System.out.print("nombre: ");
            String nom = sc.nextLine().trim();

            System.out.print("documento: ");
            String doc = sc.nextLine().trim();

            System.out.print("correo: ");
            String corr = sc.nextLine().trim();

            System.out.print("telefono: ");
            String tel = sc.nextLine().trim();

            System.out.print("contraseña (5 dígitos): ");
            String pss = sc.nextLine().trim();

            if (!pss.matches("\\d{5}")) {
                System.out.println("La contraseña debe tener exactamente 5 dígitos.\n");
                continue;
            }

            System.out.printf("\n¿Está seguro que quiere agregar estos datos?\n"
                    + "Nombre: %s\nDocumento: %s\nCorreo: %s\nTelefono: %s\nContraseña: %s\n",
                    nom, doc, corr, tel, pss);

            System.out.print("(S o N): ");
            String opc = sc.nextLine().trim();

            if (opc.equalsIgnoreCase("s") || opc.equalsIgnoreCase("si")) {
                // activo = TRUE y permiso_modificacion = FALSE vienen por DEFAULT
                String sqlInsert = "INSERT INTO clientes (nombre, documento, correo, telefono, contrasena) VALUES (?, ?, ?, ?, ?)";

                try (Connection coneccion = dbc.conectar();
                     PreparedStatement pstmt = coneccion.prepareStatement(sqlInsert)) {

                    pstmt.setString(1, nom);
                    pstmt.setString(2, doc);
                    pstmt.setString(3, corr);
                    pstmt.setString(4, tel);
                    pstmt.setString(5, pss);

                    if (pstmt.executeUpdate() > 0) {
                        System.out.println("Cliente registrado exitosamente.");
                        break;
                    }
                } catch (SQLException e) {
                    System.out.println("Error al insertar el cliente: " + e.getMessage());
                    System.out.println("Intente de nuevo.\n");
                }

            } else if (opc.equalsIgnoreCase("n") || opc.equalsIgnoreCase("no")) {
                System.out.println("Operación cancelada.");
                break;
            } else {
                System.out.println("Opción no válida. Por favor, intente de nuevo.\n");
            }
        }
    }

    public static void listarClientes() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== COMO DESEA LISTAR LOS CLIENTES ===");
        System.out.println("1.) ID\n2.) NOMBRE\n3.) DOCUMENTO\n4.) CORREO\n5.) TELEFONO");
        System.out.print("Opción: ");
        String opcion = sc.nextLine().trim();

        String columna;
        boolean parcial = false;

        switch (opcion) {
            case "1": columna = "id"; break;
            case "2": columna = "nombre"; parcial = true; break;
            case "3": columna = "documento"; break;
            case "4": columna = "correo"; break;
            case "5": columna = "telefono"; break;
            default:
                System.out.println("Opción no válida.");
                return;
        }

        System.out.print("Ingrese el valor a buscar: ");
        String valor = sc.nextLine().trim();

        if (columna.equals("id")) {
            try {
                Integer.parseInt(valor);
            } catch (NumberFormatException e) {
                System.out.println("El ID debe ser un número.");
                return;
            }
        }

        String sql = parcial
            ? "SELECT id, nombre, documento, correo, telefono FROM clientes WHERE activo = TRUE AND " + columna + " LIKE ?"
            : "SELECT id, nombre, documento, correo, telefono FROM clientes WHERE activo = TRUE AND " + columna + " = ?";

        try (Connection coneccion = dbc.conectar();
             PreparedStatement pstmt = coneccion.prepareStatement(sql)) {

            pstmt.setString(1, parcial ? "%" + valor + "%" : valor);

            try (ResultSet rs = pstmt.executeQuery()) {
                int total = 0;

                while (rs.next()) {
                    total++;
                    System.out.println("\n--- CLIENTE " + total + " ---");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Documento: " + rs.getString("documento"));
                    System.out.println("Correo: " + rs.getString("correo"));
                    System.out.println("Teléfono: " + rs.getString("telefono"));
                }

                if (total == 0) {
                    System.out.println("\nNo se encontró ningún cliente activo con ese dato.");
                } else {
                    System.out.println("\nTotal de clientes encontrados: " + total);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        }
    }

    public static void actualizarCliente() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL CLIENTE A ACTUALIZAR ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        String sqlcons = "SELECT * FROM clientes WHERE id = ? AND activo = TRUE";

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlcons)) {
            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n--- CLIENTE ENCONTRADO ---");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Documento: " + rs.getString("documento"));
                    System.out.println("Correo: " + rs.getString("correo"));
                    System.out.println("Teléfono: " + rs.getString("telefono"));
                } else {
                    System.out.println("\nNo se encontró ningún cliente activo con el ID: " + id);
                    return;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
            return;
        }

        System.out.println("\nQué campo desea actualizar:\n1. NOMBRE\n2. DOCUMENTO\n3. CORREO\n4. TELEFONO\n5. CONTRASEÑA");
        String opc = sc.nextLine().trim();

        if (opc.equals("1")) {
            System.out.print("Ingrese el nuevo nombre: ");
            String nombre = sc.nextLine().trim();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE clientes SET nombre = ? WHERE id = ? AND activo = TRUE", nombre, id, "Nombre");
            }

        } else if (opc.equals("2")) {
            System.out.print("Ingrese el nuevo documento: ");
            String documento = sc.nextLine().trim();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE clientes SET documento = ? WHERE id = ? AND activo = TRUE", documento, id, "Documento");
            }

        } else if (opc.equals("3")) {
            System.out.print("Ingrese el nuevo correo: ");
            String correo = sc.nextLine().trim();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE clientes SET correo = ? WHERE id = ? AND activo = TRUE", correo, id, "Correo");
            }

        } else if (opc.equals("4")) {
            System.out.print("Ingrese el nuevo teléfono: ");
            String telefono = sc.nextLine().trim();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE clientes SET telefono = ? WHERE id = ? AND activo = TRUE", telefono, id, "Teléfono");
            }

        } else if (opc.equals("5")) {
            System.out.print("Ingrese la nueva contraseña (5 dígitos): ");
            String pss = sc.nextLine().trim();
            if (!pss.matches("\\d{5}")) {
                System.out.println("La contraseña debe tener exactamente 5 dígitos.");
                return;
            }
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE clientes SET contrasena = ? WHERE id = ? AND activo = TRUE", pss, id, "Contraseña");
            }

        } else {
            System.out.println("Opción incorrecta.");
        }
    }

    public static void eliminarCliente() {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL CLIENTE A ELIMINAR ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        String sqlcons = "SELECT * FROM clientes WHERE id = ? AND activo = TRUE";

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlcons)) {
            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n--- CLIENTE ENCONTRADO ---");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Documento: " + rs.getString("documento"));
                    System.out.println("Correo: " + rs.getString("correo"));
                    System.out.println("Teléfono: " + rs.getString("telefono"));
                } else {
                    System.out.println("\nNo se encontró ningún cliente activo con el ID: " + id);
                    return;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
            return;
        }

        System.out.println("\n¿Está seguro que quiere eliminar este cliente?");
        if (confirmar(sc)) {
            String sqlDel = "UPDATE clientes SET activo = FALSE WHERE id = ? AND activo = TRUE";

            try (Connection coneccion = dbc.conectar();
                 PreparedStatement pstmt = coneccion.prepareStatement(sqlDel)) {

                pstmt.setInt(1, id);
                int filas = pstmt.executeUpdate();
                System.out.println(filas > 0 ? "Cliente eliminado exitosamente." : "No se pudo eliminar el cliente.");

            } catch (SQLException e) {
                System.out.println("Error al eliminar: " + e.getMessage());
            }
        }
    }

    private static boolean confirmar(Scanner sc) {
        System.out.print("¿Estás seguro? (S o N): ");
        String conf = sc.nextLine().trim();

        if (conf.equalsIgnoreCase("s")) {
            return true;
        } else if (conf.equalsIgnoreCase("n")) {
            System.out.println("Operación cancelada.");
        } else {
            System.out.println("Opción incorrecta.");
        }
        return false;
    }

    private static void ejecutarUpdate(dbConnection dbc, String sql, String valor, int id, String campo) {
        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sql)) {
            pstmt.setString(1, valor);
            pstmt.setInt(2, id);

            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("¡" + campo + " actualizado exitosamente!");
            } else {
                System.out.println("No se encontró ningún cliente activo con ese ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }
    

    
}