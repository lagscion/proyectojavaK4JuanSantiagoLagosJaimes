package com.mycompany.proyectok4juanllgos.modelo;

import com.mycompany.proyectok4juanllgos.persistencia.dbConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class prestamos {
    public static void consultarPrestamosCliente(int clienteId) {
        String sql = "SELECT p.id, e.nombre AS empleado, p.monto, p.interes, p.cuotas, "
                   + "p.fecha_inicio, p.estado, COALESCE(SUM(pg.monto), 0) AS pagado "
                   + "FROM prestamos p "
                   + "JOIN empleados e ON e.id = p.empleado_id "
                   + "LEFT JOIN pagos pg ON pg.prestamo_id = p.id "
                   + "WHERE p.cliente_id = ? "
                   + "GROUP BY p.id, e.nombre, p.monto, p.interes, p.cuotas, p.fecha_inicio, p.estado "
                   + "ORDER BY p.fecha_inicio DESC";
        listar(sql, clienteId, "Asesor", "empleado");
    }

    

    // Para el empleado: los préstamos que gestiona (solo de clientes activos)
    public static void consultarPrestamosEmpleado(int empleadoId) {
        String sql = "SELECT p.id, c.nombre AS cliente, p.monto, p.interes, p.cuotas, "
                   + "p.fecha_inicio, p.estado, COALESCE(SUM(pg.monto), 0) AS pagado "
                   + "FROM prestamos p "
                   + "JOIN clientes c ON c.id = p.cliente_id AND c.activo = TRUE "
                   + "LEFT JOIN pagos pg ON pg.prestamo_id = p.id "
                   + "WHERE p.empleado_id = ? "
                   + "GROUP BY p.id, c.nombre, p.monto, p.interes, p.cuotas, p.fecha_inicio, p.estado "
                   + "ORDER BY p.fecha_inicio DESC";
        listar(sql, empleadoId, "Cliente", "cliente");
    }

    // Ejecuta la consulta y muestra los resultados
    public static void listar(String sql, int id, String etiqueta, String columna) {
        dbConnection dbc = new dbConnection();

        try (Connection coneccion = dbc.conectar();
             PreparedStatement pstmt = coneccion.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                int total = 0;

                while (rs.next()) {
                    total++;
                    BigDecimal monto = rs.getBigDecimal("monto");
                    BigDecimal pagado = rs.getBigDecimal("pagado");

                    System.out.println("\n--- PRÉSTAMO #" + rs.getInt("id") + " ---");
                    System.out.println(etiqueta + ": " + rs.getString(columna));
                    System.out.println("Monto: $" + monto.toPlainString());
                    System.out.println("Interés: " + rs.getBigDecimal("interes") + "%");
                    System.out.println("Cuotas: " + rs.getInt("cuotas"));
                    System.out.println("Fecha de inicio: " + rs.getDate("fecha_inicio"));
                    System.out.println("Estado: " + rs.getString("estado"));
                    System.out.println("Total pagado: $" + pagado.toPlainString());
                }

                if (total == 0) {
                    System.out.println("\nNo hay préstamos relacionados.");
                } else {
                    System.out.println("\nTotal de préstamos: " + total);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        }
    }

    
}