package com.mycompany.proyectok4juanllgos.controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ingreso {

    // Resultado del login: rol + permiso
    public static class Sesion {
        public final String rol;                 // "cliente" o "empleado"
        public final boolean permisoModificacion;
        public int id;

        public Sesion(String rol, boolean permisoModificacion) {
            this.rol = rol;
            this.permisoModificacion = permisoModificacion;
        }
    }

    public Sesion autenticar(Connection conexion, String usuario, String password) {

        // 1. Buscar en clientes
        String sqlCliente = "SELECT id, permiso_modificacion FROM clientes WHERE nombre = ? AND contrasena = ? AND activo = TRUE";   // CAMBIO: pide id
try (PreparedStatement pstmt = conexion.prepareStatement(sqlCliente)) {
    pstmt.setString(1, usuario);
    pstmt.setString(2, password);

    try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
            boolean permiso = rs.getBoolean("permiso_modificacion");
            Sesion s = new Sesion("cliente", permiso);   // CAMBIO
            s.id = rs.getInt("id");                       // NUEVO
            return s;                                     // CAMBIO
        }
    }
} catch (SQLException e) {
    System.out.println("Error al consultar clientes: " + e.getMessage());
}
        // 2. Buscar en empleados (aquí sí existe permiso_modificacion)
        String sqlEmpleado = "SELECT id, permiso_modificacion FROM empleados WHERE nombre = ? AND contrasena = ? and activo = TRUE";   // CAMBIO: pide id
        try (PreparedStatement pstmt = conexion.prepareStatement(sqlEmpleado)) {
            pstmt.setString(1, usuario);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    boolean permiso = rs.getBoolean("permiso_modificacion");
                    Sesion s = new Sesion("empleado", permiso);   // CAMBIO
                    s.id = rs.getInt("id");                        // NUEVO
                    return s;                                      // CAMBIO
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar empleados: " + e.getMessage());
        }

        return null; // credenciales incorrectas
    }
}