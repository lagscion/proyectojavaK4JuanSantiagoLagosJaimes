package com.mycompany.proyectok4juanllgos.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO {

    public boolean registrarPrestamo(double monto, double tasa, int clienteId) {
        String sql = "INSERT INTO prestamos (monto, tasa, cliente_id) VALUES (?, ?, ?)";
        try (Connection conn = dbConnection.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (conn == null) {
                throw new SQLException("No se pudo establecer conexión con la base de datos.");
            }
            pstmt.setDouble(1, monto);
            pstmt.setDouble(2, tasa);
            pstmt.setInt(3, clienteId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar el préstamo: " + e.getMessage());
            return false;
        }
    }

    public List<String> listarPrestamos() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT id, monto, tasa, cliente_id FROM prestamos";
        try (Connection conn = dbConnection.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (conn == null) {
                throw new SQLException("No se pudo establecer conexión con la base de datos.");
            }
            while (rs.next()) {
                String registro = String.format("ID: %d | Monto: %.2f | Tasa: %.2f%% | Cliente ID: %d",
                        rs.getInt("id"),
                        rs.getDouble("monto"),
                        rs.getDouble("tasa"),
                        rs.getInt("cliente_id"));
                lista.add(registro);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar préstamos: " + e.getMessage());
        }
        return lista;
    }
}
