/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to edit this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectok4juanllgos.modelo;

import com.mycompany.proyectok4juanllgos.persistencia.dbConnection;

import com.mysql.cj.x.protobuf.MysqlxPrepare;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

public class empleados {

    public static void registrarEmpleado() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE LOS SIGUIENTES DATOS ===");

        while (true) {
            System.out.print("nombre: ");
            String nom = sc.nextLine();
            System.out.print("documento: ");
            int doc = sc.nextInt();
            sc.nextLine();
            System.out.print("rol: ");
            String rol = sc.nextLine();
            System.out.print("correo: ");
            String corr = sc.nextLine();
            System.out.print("contraseña: ");
            String pss = sc.nextLine();
            System.out.println("sueldo: ");
            long sal = sc.nextLong();
            sc.nextLine();

            System.out.printf("\n¿Está seguro que quiere agregar estos datos?\n"
                    + "Nombre: %s\n"
                    + "Documento: %d\n"
                    + "Rol: %s\n"
                    + "Correo: %s\n"
                    + "Sueldo: $%d\n(s/n): ",
                    nom, doc, rol, corr, sal);

            System.out.print("S o N? ");
            String opc = sc.nextLine();

            if (opc.equalsIgnoreCase("s") || opc.equalsIgnoreCase("si")) {

                String sqlInsert = "INSERT INTO empleados (nombre, documento, rol, correo, contrasena, salario) VALUES (?, ?, ?, ?, ?, ?)";

                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlInsert)) {

                    pstmt.setString(1, nom);
                    pstmt.setInt(2, doc);
                    pstmt.setString(3, rol);
                    pstmt.setString(4, corr);
                    pstmt.setString(5, pss);
                    pstmt.setLong(6, sal);

                    int filasAfectadas = pstmt.executeUpdate();
                    if (filasAfectadas > 0) {
                        System.out.println("Empleado registrado exitosamente.");
                        break;
                    }

                } catch (SQLException e) {
                    System.out.println("Error al insertar el empleado: " + e.getMessage());
                }

            } else if (opc.equalsIgnoreCase("n") || opc.equalsIgnoreCase("no")) {
                System.out.println("Operación cancelada.");
                break;
            } else {
                System.out.println("Opción no válida. Por favor, intente de nuevo.\n");
            }
        }
    }

    public static void consultarEmpleado() throws SQLException {

        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== COMO DESEA CONSULTAR EL EMPLEADO ===\n1.) ID\n2.) NOMBRE\n3.) DOCUMENTO\n4.) CORREO");
        int opcion = sc.nextInt();
        sc.nextLine();

        switch (opcion) {
            case 1:
                System.out.print("Ingrese el ID a consultar: ");
                int id = sc.nextInt();
                sc.nextLine();

                String sqlcons = "SELECT * FROM empleados WHERE id = ? and activo = TRUE";

                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlcons)) {
                    pstmt.setInt(1, id);

                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                            System.out.println("ID: " + rs.getInt("id"));
                            System.out.println("Nombre: " + rs.getString("nombre"));
                            System.out.println("Documento: " + rs.getInt("documento"));
                            System.out.println("Rol: " + rs.getString("rol"));
                            System.out.println("Correo: " + rs.getString("correo"));
                            System.out.println("Sueldo: $" + rs.getLong("salario"));
                        } else {
                            System.out.println("\nNo se encontró ningún empleado con el ID: " + id);
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("Error en la consulta: " + e.getMessage());
                }
                break;

            case 2:
                System.out.print("Ingrese el nombre a consultar: ");
                String nom = sc.nextLine();

                String sqlconsName = "SELECT * FROM empleados WHERE nombre = ? and activo = TRUE";

                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlconsName)) {
                    pstmt.setString(1, nom);

                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                            System.out.println("ID: " + rs.getInt("id"));
                            System.out.println("Nombre: " + rs.getString("nombre"));
                            System.out.println("Documento: " + rs.getInt("documento"));
                            System.out.println("Rol: " + rs.getString("rol"));
                            System.out.println("Correo: " + rs.getString("correo"));
                            System.out.println("Sueldo: $" + rs.getLong("salario"));
                        } else {
                            System.out.println("\nNo se encontró ningún empleado con el nombre: " + nom);
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("Error en la consulta: " + e.getMessage());
                }
                break;

            case 3:
                System.out.print("Ingrese el documento a consultar: "); // Corregido el texto
                String doc = sc.nextLine();

                String sqlconsDoc = "SELECT * FROM empleados WHERE documento = ? and activo = TRUE";

                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlconsDoc)) {
                    pstmt.setString(1, doc);

                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                            System.out.println("ID: " + rs.getInt("id"));
                            System.out.println("Nombre: " + rs.getString("nombre"));
                            System.out.println("Documento: " + rs.getInt("documento"));
                            System.out.println("Rol: " + rs.getString("rol"));
                            System.out.println("Correo: " + rs.getString("correo"));
                            System.out.println("Sueldo: $" + rs.getLong("salario"));
                        } else {
                            System.out.println("\nNo se encontró ningún empleado con el documento: " + doc);
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("Error en la consulta: " + e.getMessage());
                }
                break;

            case 4:
                System.out.print("Ingrese el correo a consultar: ");
                String corr = sc.nextLine();

                String sqlconsEmail = "SELECT * FROM empleados WHERE correo = ? and activo = TRUE";

                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlconsEmail)) {
                    pstmt.setString(1, corr);

                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                            System.out.println("ID: " + rs.getInt("id"));
                            System.out.println("Nombre: " + rs.getString("nombre"));
                            System.out.println("Documento: " + rs.getInt("documento"));
                            System.out.println("Rol: " + rs.getString("rol"));
                            System.out.println("Correo: " + rs.getString("correo"));
                            System.out.println("Sueldo: $" + rs.getLong("salario"));
                        } else {
                            System.out.println("\nNo se encontró ningún empleado con el correo: " + corr);
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("Error en la consulta: " + e.getMessage());
                }
                break;

            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    public static void actualizarEmpleado() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL EMPLEADO A ACTUALIZAR ===");
        int id = Integer.parseInt(sc.nextLine());

        String sqlcons = "SELECT * FROM empleados WHERE id = ?";

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlcons)) {
            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Documento: " + rs.getString("documento"));
                    System.out.println("Rol: " + rs.getString("rol"));
                    System.out.println("Correo: " + rs.getString("correo"));
                    System.out.println("Sueldo: $" + rs.getLong("salario"));
                } else {
                    System.out.println("\nNo se encontró ningún empleado con el ID: " + id);
                    return;   // si no existe, no tiene sentido seguir
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
            return;
        }

        System.out.println("\nQué campo desea actualizar:\n1. NOMBRE\n2. DOCUMENTO\n3. ROL\n4. SALARIO");
        String opc = sc.nextLine();

        if (opc.equals("1")) {
            System.out.print("Ingrese el nuevo nombre: ");
            String nombre = sc.nextLine();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE empleados SET nombre = ? WHERE id = ?", nombre, id, "Nombre");
            }

        } else if (opc.equals("2")) {
            System.out.print("Ingrese el nuevo documento: ");
            String documento = sc.nextLine();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE empleados SET documento = ? WHERE id = ?", documento, id, "Documento");
            }

        } else if (opc.equals("3")) {
            System.out.print("Ingrese el nuevo rol: ");
            String rol = sc.nextLine();
            if (confirmar(sc)) {
                ejecutarUpdate(dbc, "UPDATE empleados SET rol = ? WHERE id = ?", rol, id, "Rol");
            }

        } else if (opc.equals("4")) {
            System.out.print("Ingrese el nuevo salario : ");
            float salario = sc.nextFloat();
            sc.nextLine();

            if (confirmar(sc)) {
                String sql = "UPDATE empleados SET salario = ? WHERE id = ?";
                try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sql)) {

                    pstmt.setFloat(1, salario);
                    pstmt.setInt(2, id);

                    int filas = pstmt.executeUpdate();
                    System.out.println(filas > 0 ? "¡Salario actualizado exitosamente!" : "No se encontró ningún empleado con ese ID.");
                } catch (SQLException e) {
                    System.out.println("Error al actualizar: " + e.getMessage());
                }
            }

        } else {
            System.out.println("Opción incorrecta.");
        }
    }

    private static boolean confirmar(Scanner sc) {
        System.out.print("¿Estás seguro? (S o N): ");
        String conf = sc.nextLine().trim();

        if (conf.equalsIgnoreCase("s")) {
            return true;
        } else if (conf.equalsIgnoreCase("n")) {
            System.out.println("Operación cancelada.");
        } else {
            System.out.println("Opción incorrecta.");
        }
        return false;
    }

    private static void ejecutarUpdate(dbConnection dbc, String sql, String valor, int id, String campo) {
        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sql)) {
            pstmt.setString(1, valor);
            pstmt.setInt(2, id);

            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("¡" + campo + " actualizado exitosamente!");
            } else {
                System.out.println("No se encontró ningún empleado con ese ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }
    }

    public static void eliminarEmpleado() {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL EMPLEADO A ELIMINAR ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        // Solo busca empleados que sigan activos
        String sqlcons = "SELECT * FROM empleados WHERE id = ? AND activo = TRUE";

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlcons)) {
            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n--- EMPLEADO ENCONTRADO ---");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Documento: " + rs.getString("documento"));
                    System.out.println("Rol: " + rs.getString("rol"));
                    System.out.println("Correo: " + rs.getString("correo"));
                    System.out.println("Sueldo: $" + rs.getBigDecimal("salario").toPlainString());
                } else {
                    System.out.println("\nNo se encontró ningún empleado activo con el ID: " + id);
                    return;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
            return;
        }

        System.out.println("\n¿Está seguro que quiere eliminar este empleado?");
        if (confirmar(sc)) {
            // En vez de DELETE, se cambia el estado a inactivo
            String sqlDel = "UPDATE empleados SET activo = FALSE WHERE id = ?";

            try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlDel)) {

                pstmt.setInt(1, id);

                int filas = pstmt.executeUpdate();
                System.out.println(filas > 0 ? "Empleado eliminado exitosamente." : "No se pudo eliminar el empleado.");

            } catch (SQLException e) {
                System.out.println("Error al eliminar: " + e.getMessage());
            }
        }
    }

    public static void crearPrestamo(int empleadoId) {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE LOS SIGUIENTES DATOS ===");

        // 1. Validar cliente
        System.out.print("ID del cliente para el préstamo: ");
        int clienteId;
        try {
            clienteId = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        String sqlCliente = "SELECT nombre FROM clientes WHERE id = ? AND activo = TRUE";
        String nombreCliente;

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlCliente)) {

            pstmt.setInt(1, clienteId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    nombreCliente = rs.getString("nombre");
                    System.out.println("Cliente permitido: " + nombreCliente);
                } else {
                    System.out.println("El cliente no existe o no está disponible.");
                    return;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el cliente: " + e.getMessage());
            return;
        }

        // 2. Pedir datos del préstamo
        BigDecimal monto;
        BigDecimal interes;
        int cuotas;

        try {
            System.out.print("Monto (ej: 5000000): ");
            monto = new BigDecimal(sc.nextLine().trim());
            if (monto.signum() <= 0 || monto.compareTo(new BigDecimal("9999999999.99")) > 0) {
                System.out.println("El monto debe ser mayor a 0 y menor a 10.000.000.000.");
                return;
            }

            System.out.print("Interés mensual en % (ej: 1.80): ");
            interes = new BigDecimal(sc.nextLine().trim());
            if (interes.signum() <= 0 || interes.compareTo(new BigDecimal("999.99")) > 0) {
                System.out.println("El interés debe ser mayor a 0 y menor a 1000.");
                return;
            }

            System.out.print("Número de cuotas: ");
            cuotas = Integer.parseInt(sc.nextLine().trim());
            if (cuotas <= 0) {
                System.out.println("Las cuotas deben ser mayores a 0.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Dato inválido. Use solo números (punto para decimales, sin separadores de miles).");
            return;
        }

        // 3. Calcular cuota mensual y total a pagar (cuota fija, sistema francés)
        BigDecimal i = interes.divide(new BigDecimal("100"), MathContext.DECIMAL128);
        BigDecimal factor = BigDecimal.ONE.add(i).pow(cuotas, MathContext.DECIMAL128);
        BigDecimal divisor = BigDecimal.ONE.subtract(BigDecimal.ONE.divide(factor, MathContext.DECIMAL128));
        BigDecimal cuotaMensual = monto.multiply(i).divide(divisor, 2, RoundingMode.HALF_UP);
        BigDecimal totalAPagar = cuotaMensual.multiply(new BigDecimal(cuotas));

        // 4. Confirmar
        System.out.printf("%n¿Crear este préstamo?%nCliente: %s%nMonto: $%s%nInterés: %s%%%nCuotas: %d%n"
                + "Cuota mensual: $%s%nTotal a pagar: $%s%nFecha de inicio: %s%n",
                nombreCliente, monto.toPlainString(), interes.toPlainString(), cuotas,
                cuotaMensual.toPlainString(), totalAPagar.toPlainString(), LocalDate.now());
        System.out.print("(S o N): ");
        String conf = sc.nextLine().trim();

        if (!conf.equalsIgnoreCase("s") && !conf.equalsIgnoreCase("si")) {
            System.out.println("Operación cancelada.");
            return;
        }

        // 5. Insertar
        String sqlInsert = "INSERT INTO prestamos (cliente_id, empleado_id, monto, interes, cuotas, fecha_inicio, estado) "
                + "VALUES (?, ?, ?, ?, ?, CURDATE(), 'Activo')";

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlInsert)) {

            pstmt.setInt(1, clienteId);
            pstmt.setInt(2, empleadoId);
            pstmt.setBigDecimal(3, monto);
            pstmt.setBigDecimal(4, interes);
            pstmt.setInt(5, cuotas);

            if (pstmt.executeUpdate() > 0) {
                System.out.println("Préstamo creado exitosamente.");
            } else {
                System.out.println("No se pudo crear el préstamo.");
            }
        } catch (SQLException e) {
            System.out.println("Error al crear el préstamo: " + e.getMessage());
        }
    }

    public static void cambiarEstado() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL PRESTAMO A CAMBIAR DE ESTADO ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        String sqlPrestamo = "select * from prestamos p where id = ? and p.estado = 'Activo'";
        boolean prestamoEncontrado = false; // 1. Bandera para controlar si existe

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlPrestamo)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    prestamoEncontrado = true; // 2. Se marca como encontrado

                    System.out.println("\n=== PRESTAMO ===");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("CLIENTE ID: " + rs.getInt("cliente_id"));
                    System.out.println("EMPLEADO ID: " + rs.getInt("empleado_id"));
                    System.out.println("MONTO: " + rs.getBigDecimal("monto"));
                    System.out.println("INTERES: " + rs.getBigDecimal("interes"));
                    System.out.println("CUOTAS: " + rs.getInt("cuotas"));
                    System.out.println("FECHA INICIO: " + rs.getDate("fecha_inicio"));
                    System.out.println("ESTADO: " + rs.getNString("estado"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
            return;
        }

        // 3. Si no se encontró el préstamo activo, detenemos el método aquí mismo
        if (!prestamoEncontrado) {
            System.out.println("No se encontró ningún préstamo activo con ese ID.");
            return;
        }

        System.out.println("=== A QUE ESTADO LO QUIERE CAMBIAR ===\n1.PAGADO\n2.MORA");
        int opc = sc.nextInt();
        sc.nextLine(); // Limpiar el buffer

        String estado = "";
        if (opc == 1) {
            estado = "Pagado";
        } else if (opc == 2) {
            estado = "Mora";
        } else {
            System.out.println("Opción no válida.");
            return;
        }

        String sqlUpdt = "update prestamos set estado = ? where id = ?";

        try (Connection conexion = dbc.conectar(); PreparedStatement pstmt = conexion.prepareStatement(sqlUpdt)) {
            pstmt.setString(1, estado);
            pstmt.setInt(2, id);

            int columnasAfectadas = pstmt.executeUpdate();
            if (columnasAfectadas > 0) {
                System.out.println("¡Estado actualizado correctamente!");
            } else {
                System.out.println("la operacion no se logro realizar");
            }
        }
    }

    public static void abonos() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL PRESTAMO A ABONAR ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        String sqlPrestamo = "select * from prestamos p where id = ? and p.estado = 'Activo'";
        boolean prestamoEncontrado = false;
        BigDecimal montoPrestamo = BigDecimal.ZERO; 

        try (Connection coneccion = dbc.conectar(); PreparedStatement pstmt = coneccion.prepareStatement(sqlPrestamo)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    prestamoEncontrado = true;

                    System.out.println("\n=== PRESTAMO ===");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("CLIENTE ID: " + rs.getInt("cliente_id"));
                    System.out.println("EMPLEADO ID: " + rs.getInt("empleado_id"));
                    System.out.println("MONTO: " + rs.getBigDecimal("monto"));
                    System.out.println("INTERES: " + rs.getBigDecimal("interes"));
                    System.out.println("CUOTAS: " + rs.getInt("cuotas"));
                    System.out.println("FECHA INICIO: " + rs.getDate("fecha_inicio"));
                    System.out.println("ESTADO: " + rs.getNString("estado"));

                    montoPrestamo = rs.getBigDecimal("monto");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
            return;
        }

        if (!prestamoEncontrado) {
            System.out.println("No se encontró ningún préstamo activo con ese ID.");
            return;
        }

        System.out.println("=== QUE VALOR DESEA ABONAR ===");

        BigDecimal valorAbono;
        try {
            valorAbono = new BigDecimal(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Valor ingresado inválido.");
            return;
        }

       
        if (valorAbono.compareTo(BigDecimal.ZERO) > 0 && valorAbono.compareTo(montoPrestamo) <= 0) {
           BigDecimal result = montoPrestamo.subtract(valorAbono);
           if (result.compareTo(BigDecimal.ZERO)==0){
               String estado = "Pagado";
               
               String sqlpdt = "update prestamos set monto = ? , estado = ?   where id = ?";
               
               try (Connection conexion = dbc.conectar(); PreparedStatement pstmt = conexion.prepareStatement(sqlpdt)) {
                   
                    pstmt.setBigDecimal(1, result);
                    pstmt.setString(2, estado);
                    pstmt.setInt(3, id);

            int columnasAfectadas = pstmt.executeUpdate();
            if (columnasAfectadas > 0) {
                System.out.println("¡monto abonado correctamente!");
            } else {
                System.out.println("la operacion no se logro realizar");
            }
        }
               
           }else{
                String sqlpdt = "update prestamos set monto =  ?   where id = ?";
               
               try (Connection conexion = dbc.conectar(); PreparedStatement pstmt = conexion.prepareStatement(sqlpdt)) {
                   
                    pstmt.setBigDecimal(1, result); 
                    pstmt.setInt(2, id);

            int columnasAfectadas = pstmt.executeUpdate();
            if (columnasAfectadas > 0) {
                System.out.println("¡monto abonado correctamente!");
            } else {
                System.out.println("la operacion no se logro realizar");
            }
        }
           }
        } else {
            System.out.println("El valor del abono debe ser mayor a 0 y no puede superar el monto total del préstamo.");
        }
        
    }
    
    public static void mostrarHistoricoPagos() throws SQLException {
        dbConnection dbc = new dbConnection();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== INGRESE EL ID DEL PRESTAMO PARA VER SU HISTORICO DE PAGOS ===");
        int id;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }

        // Consulta para obtener los pagos y verificar el préstamo
        String sqlHistorico = "p.id, p.monto AS monto_prestamo, p.estado, pg.fecha_pago, pg.monto AS monto_pago "
                + "FROM prestamos p LEFT JOIN pagos pg ON p.id = pg.prestamo_id WHERE p.id = ?";
        
        // Ajustamos la consulta para ser más limpia usando las dos tablas
        String sqlValidar = "SELECT * FROM prestamos WHERE id = ?";
        String sqlPagos = "SELECT * FROM pagos WHERE prestamo_id = ?";

        try (Connection coneccion = dbc.conectar()) {
            
            // Primero validamos si el préstamo existe
            try (PreparedStatement pstmtVal = coneccion.prepareStatement(sqlValidar)) {
                pstmtVal.setInt(1, id);
                try (ResultSet rsVal = pstmtVal.executeQuery()) {
                    if (!rsVal.next()) {
                        System.out.println("No se encontró ningún préstamo con el ID: " + id);
                        return;
                    }
                    System.out.println("\n=== HISTÓRICO DE PAGOS - PRÉSTAMO ID: " + id + " ===");
                }
            }

            // Luego consultamos los pagos registrados
            try (PreparedStatement pstmtPagos = coneccion.prepareStatement(sqlPagos)) {
                pstmtPagos.setInt(1, id);
                try (ResultSet rsPagos = pstmtPagos.executeQuery()) {
                    boolean hayPagos = false;
                    int contador = 1;

                    while (rsPagos.next()) {
                        hayPagos = true;
                        System.out.println("\n--- Pago #" + contador + " ---");
                        System.out.println("ID del Pago: " + rsPagos.getInt("id"));
                        System.out.println("Fecha de Pago: " + rsPagos.getDate("fecha_pago"));
                        System.out.println("Monto Abonado: $" + rsPagos.getBigDecimal("monto").toPlainString());
                        contador++;
                    }

                    if (!hayPagos) {
                        System.out.println("Este préstamo aún no registra pagos o abonos.");
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar el histórico de pagos: " + e.getMessage());
        }
    }
    
    public static void consultarReportesPrestamos() {
    dbConnection dbc = new dbConnection();
    Scanner sc = new Scanner(System.in);

    System.out.println("\n=== MENÚ DE REPORTES Y CONSULTAS ===");
    System.out.println("1. Consultar Préstamos Activos");
    System.out.println("2. Consultar Préstamos en Mora");
    System.out.println("3. Consultar Clientes Morosos");
    System.out.print("Seleccione una opción: ");

    int opcion;
    try {
        opcion = Integer.parseInt(sc.nextLine().trim());
    } catch (NumberFormatException e) {
        System.out.println("Opción inválida. Debe ingresar un número.");
        return;
    }

    String sql = "";

    switch (opcion) {
        case 1:
            sql = "SELECT * FROM prestamos WHERE estado = 'Activo'";
            System.out.println("\n=== LISTADO DE PRÉSTAMOS ACTIVOS ===");
            break;
        case 2:
            sql = "SELECT * FROM prestamos WHERE estado = 'Mora'";
            System.out.println("\n=== LISTADO DE PRÉSTAMOS EN MORA ===");
            break;
        case 3:
            sql = "SELECT DISTINCT c.id, c.nombre, c.documento, c.correo, c.telefono " +
                  "FROM clientes c " +
                  "JOIN prestamos p ON c.id = p.cliente_id " +
                  "WHERE p.estado = 'Mora'";
            System.out.println("\n=== LISTADO DE CLIENTES MOROSOS ===");
            break;
        default:
            System.out.println("Opción no válida.");
            return;
    }

    try (Connection coneccion = dbc.conectar(); 
         PreparedStatement pstmt = coneccion.prepareStatement(sql); 
         ResultSet rs = pstmt.executeQuery()) {

        boolean encontrados = false;

        while (rs.next()) {
            encontrados = true;
            System.out.println("----------------------------------------");
            
            // Si la opción es 1 o 2, mostramos datos del préstamo
            if (opcion == 1 || opcion == 2) {
                System.out.println("ID Préstamo: " + rs.getInt("id"));
                System.out.println("Cliente ID: " + rs.getInt("cliente_id"));
                System.out.println("Monto: $" + rs.getBigDecimal("monto").toPlainString());
                System.out.println("Interés: " + rs.getBigDecimal("interes") + "%");
                System.out.println("Cuotas: " + rs.getInt("cuotas"));
                System.out.println("Fecha de Inicio: " + rs.getDate("fecha_inicio"));
                System.out.println("Estado: " + rs.getString("estado"));
            } 
            // Si la opción es 3, mostramos datos del cliente
            else if (opcion == 3) {
                System.out.println("Cliente ID: " + rs.getInt("id"));
                System.out.println("Nombre: " + rs.getString("nombre"));
                System.out.println("Documento: " + rs.getString("documento"));
                System.out.println("Correo: " + rs.getString("correo"));
                System.out.println("Teléfono: " + rs.getString("telefono"));
            }
        }

        if (!encontrados) {
            System.out.println("No se encontraron registros para esta consulta.");
        }
        System.out.println("----------------------------------------");

    } catch (SQLException e) {
        System.out.println("Error al ejecutar la consulta: " + e.getMessage());
    }
}
}
