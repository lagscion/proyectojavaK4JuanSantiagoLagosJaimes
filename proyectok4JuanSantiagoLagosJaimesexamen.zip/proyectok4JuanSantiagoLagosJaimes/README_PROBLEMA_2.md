# Problema 2: cálculo financiero unificado

Se unificó el cálculo de préstamos con el sistema francés de amortización (cuota fija).

## Convenciones
- `prestamos.monto`: capital original del préstamo.
- `prestamos.interes`: tasa mensual en porcentaje; por ejemplo, `2.00` representa 2 % mensual.
- `prestamos.cuotas`: número de mensualidades.
- La tasa se convierte a fracción para el cálculo: 2 % = 0.02.
- La cuota mensual se calcula con `Q = C * i / (1 - (1 + i)^(-n))`.
- El total se calcula como cuota mensual redondeada a dos decimales multiplicada por el número de cuotas.
- El saldo pendiente es total menos la suma de los pagos registrados en `pagos`.

## Archivos modificados
- `modelo/CalculoPrestamo.java`: única implementación de la fórmula financiera.
- `modelo/Prestamo.java`: utiliza el cálculo centralizado para cuota, total y saldo.
- `modelo/empleados.java`: muestra el cálculo centralizado al crear un préstamo.
- `persistencia/PagoDAO.java`: valida abonos y calcula el saldo con la misma fórmula; bloquea la fila del préstamo durante la transacción.
- `persistencia/PrestamoDAOJDBC.java`: calcula el saldo de préstamos activos con el sistema francés.
- `modelo/prestamos.java`: consultas de préstamos muestran cuota, total, pagos acumulados y saldo pendiente.

## Importante
No se agregaron columnas a MySQL. Los importes derivados se calculan a partir de `monto`, `interes`, `cuotas` y los registros de `pagos`.

La cuota se redondea a dos decimales antes de calcular el total, igual que en la pantalla de creación. Por esa razón el último pago puede requerir un ajuste de centavos en la práctica; el sistema permite abonos por cualquier valor positivo hasta el saldo exacto.

## Validación
Todos los archivos Java compilaron correctamente con `javac` usando nivel de lenguaje Java 17. La conexión y las consultas SQL deben probarse contra la instancia MySQL del usuario.
