# Problema 3: integración de DAO con el menú

## Cambios

- `Main.java` ya no contiene consultas SQL ni utiliza las clases antiguas `clientes`, `empleados` o `prestamos` para ejecutar operaciones del menú.
- El menú utiliza `ClienteServicio`, `EmpleadoServicio`, `PrestamoServicio`, `PagoServicio` y `ReporteServicio`.
- Los servicios delegan la persistencia a `ClienteDAO`, `EmpleadoDAO`, `PrestamoDAOJDBC` y `PagoDAO`.
- Se añadieron operaciones CRUD básicas para clientes y empleados (registro, listado, actualización y desactivación lógica).
- Los préstamos se consultan mediante DAO y se muestran con capital, cuota, total, pagos, saldo y fechas.
- El histórico de pagos se consulta desde `PagoDAO`.
- Los reportes de préstamos activos, vencidos y clientes morosos se filtran con Lambda y Stream API.
- `dbConnection` ahora delega en `ConexionBD`, para evitar dos configuraciones distintas de conexión.

## Arquitectura

`Main -> Servicio -> DAO -> ConexionBD -> MySQL`

La autenticación conserva el controlador `ingreso`, pero ahora recibe una conexión obtenida por `ConexionBD`.

## Configuración

Configura `src/main/resources/db.properties` (a partir de `db.properties.example`) o las variables `DB_URL`, `DB_USER` y `DB_PASSWORD`.

## Verificación

Todos los archivos Java compilaron con `javac --release 17`.
No se ejecutó una prueba de integración contra un servidor MySQL real; es necesario probar las operaciones con tu base de datos.

## Nota sobre clases heredadas

Las clases antiguas `modelo/clientes.java`, `modelo/empleados.java`, `modelo/prestamos.java` y `persistencia/PrestamoDAO.java` se conservan para no borrar código original, pero el nuevo `Main.java` ya no las invoca. Las operaciones activas del menú pasan por servicios y DAO.
- La autenticación también se separó: `Main -> AutenticacionServicio -> AutenticacionDAO`; el controlador antiguo `ingreso` queda marcado como legado y ya no es invocado por el menú.
