package com.mycompany.proyectok4juanllgos.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Consultas de autenticación para clientes y empleados. */
public class AutenticacionDAO {
    public static class DatosSesion {
        public final int id;
        public final String rol;
        public final boolean permisoModificacion;
        public DatosSesion(int id,String rol,boolean permisoModificacion){
            this.id=id;this.rol=rol;this.permisoModificacion=permisoModificacion;
        }
    }

    public DatosSesion autenticar(String usuario,int password) throws SQLException {
        String sqlCliente="SELECT id,permiso_modificacion FROM clientes WHERE nombre=? AND contrasena=? AND activo=TRUE";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sqlCliente)){
            ps.setString(1,usuario);ps.setInt(2,password);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next())return new DatosSesion(rs.getInt("id"),"cliente",rs.getBoolean("permiso_modificacion"));
            }
        }
        String sqlEmpleado="SELECT id,permiso_modificacion FROM empleados WHERE nombre=? AND contrasena=? AND activo=TRUE";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sqlEmpleado)){
            ps.setString(1,usuario);ps.setInt(2,password);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next())return new DatosSesion(rs.getInt("id"),"empleado",rs.getBoolean("permiso_modificacion"));
            }
        }
        return null;
    }
}
