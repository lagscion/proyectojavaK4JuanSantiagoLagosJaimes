package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.persistencia.PagoDAO;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/** Orquesta registro y consulta de pagos. */
public class PagoServicio {
    private final PagoDAO dao;
    public PagoServicio(){this(new PagoDAO());}
    public PagoServicio(PagoDAO dao){this.dao=dao;}
    public void registrar(int prestamoId,BigDecimal monto,java.sql.Date fecha)throws SQLException{dao.registrar(prestamoId,monto,fecha);}
    public List<Map<String,Object>> historico(Integer prestamoId)throws SQLException{return dao.historico(prestamoId);}
}
