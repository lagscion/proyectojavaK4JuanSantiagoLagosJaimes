package com.mycompany.proyectok4juanllgos.persistencia;

import java.sql.Connection;
import java.sql.SQLException;

/** Adaptador de compatibilidad. Toda la configuración se centraliza en ConexionBD. */
public class dbConnection {
    public static Connection conectar() {
        try {
            return ConexionBD.obtener();
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }
}
