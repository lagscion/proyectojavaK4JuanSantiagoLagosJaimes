package com.mycompany.proyectok4juanllgos.modelo;

public class Cliente extends Persona {
    private String documento, correo;
    public Cliente(int id, String nombre, String telefono, String documento, String correo) {
        super(id,nombre,telefono); this.documento=documento; this.correo=correo;
    }
    public String getDocumento(){return documento;} public void setDocumento(String v){documento=v;}
    public String getCorreo(){return correo;} public void setCorreo(String v){correo=v;}
    @Override public String mostrarRol(){return "CLIENTE";}
}
