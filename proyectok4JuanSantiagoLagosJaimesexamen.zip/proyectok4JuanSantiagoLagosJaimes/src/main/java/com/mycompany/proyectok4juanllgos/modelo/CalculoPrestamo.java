package com.mycompany.proyectok4juanllgos.modelo;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Centraliza los cálculos del sistema francés de amortización.
 * La tasa recibida debe estar expresada como fracción: 0.02 representa 2 %.
 */
public final class CalculoPrestamo {
    private static final BigDecimal CIEN = new BigDecimal("100");
    private static final MathContext MC = MathContext.DECIMAL128;

    private CalculoPrestamo() {
    }

    public static BigDecimal convertirPorcentajeAFraccion(BigDecimal porcentaje) {
        if (porcentaje == null || porcentaje.signum() < 0) {
            throw new IllegalArgumentException("La tasa de interés no puede ser negativa.");
        }
        return porcentaje.divide(CIEN, MC);
    }

    public static BigDecimal calcularCuotaMensual(BigDecimal capital, BigDecimal tasaMensual, int cuotas) {
        validar(capital, tasaMensual, cuotas);

        if (tasaMensual.signum() == 0) {
            return capital.divide(BigDecimal.valueOf(cuotas), 2, RoundingMode.HALF_UP);
        }

        BigDecimal factor = BigDecimal.ONE.add(tasaMensual).pow(cuotas, MC);
        BigDecimal divisor = BigDecimal.ONE.subtract(BigDecimal.ONE.divide(factor, MC));
        return capital.multiply(tasaMensual).divide(divisor, 2, RoundingMode.HALF_UP);
    }

    public static BigDecimal calcularTotal(BigDecimal capital, BigDecimal tasaMensual, int cuotas) {
        BigDecimal cuota = calcularCuotaMensual(capital, tasaMensual, cuotas);
        return cuota.multiply(BigDecimal.valueOf(cuotas)).setScale(2, RoundingMode.HALF_UP);
    }

    public static BigDecimal calcularSaldo(BigDecimal capital, BigDecimal tasaMensual, int cuotas, BigDecimal totalPagado) {
        if (totalPagado == null || totalPagado.signum() < 0) {
            throw new IllegalArgumentException("El total pagado no puede ser negativo.");
        }
        BigDecimal saldo = calcularTotal(capital, tasaMensual, cuotas).subtract(totalPagado)
                .setScale(2, RoundingMode.HALF_UP);
        return saldo.max(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
    }

    private static void validar(BigDecimal capital, BigDecimal tasaMensual, int cuotas) {
        if (capital == null || capital.signum() <= 0) {
            throw new IllegalArgumentException("El capital debe ser mayor que cero.");
        }
        if (tasaMensual == null || tasaMensual.signum() < 0) {
            throw new IllegalArgumentException("La tasa mensual no puede ser negativa.");
        }
        if (cuotas <= 0) {
            throw new IllegalArgumentException("El número de cuotas debe ser mayor que cero.");
        }
    }
}
