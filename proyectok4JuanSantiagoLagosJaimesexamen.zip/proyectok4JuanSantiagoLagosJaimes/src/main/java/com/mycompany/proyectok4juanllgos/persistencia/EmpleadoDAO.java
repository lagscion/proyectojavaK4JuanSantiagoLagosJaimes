package com.mycompany.proyectok4juanllgos.persistencia;

import com.mycompany.proyectok4juanllgos.modelo.Empleado;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Acceso exclusivo a la tabla empleados. */
public class EmpleadoDAO {
    public int guardar(Empleado empleado, int contrasena) throws SQLException {
        String sql="INSERT INTO empleados(nombre,documento,rol,correo,contrasena,salario) VALUES(?,?,?,?,?,?)";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1,empleado.getNombre());ps.setString(2,empleado.getDocumento());ps.setString(3,empleado.getRol());
            ps.setString(4,empleado.getCorreo());ps.setInt(5,contrasena);ps.setBigDecimal(6,empleado.getSalario());ps.executeUpdate();
            try(ResultSet rs=ps.getGeneratedKeys()){if(rs.next())return rs.getInt(1);}
        }
        return -1;
    }

    public List<Empleado> listar() throws SQLException {
        List<Empleado> lista=new ArrayList<>();
        String sql="SELECT id,nombre,documento,rol,correo,salario FROM empleados WHERE activo=TRUE ORDER BY nombre";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql);ResultSet rs=ps.executeQuery()) {
            while(rs.next()) lista.add(new Empleado(rs.getInt("id"),rs.getString("nombre"),null,rs.getString("documento"),rs.getString("rol"),rs.getString("correo"),rs.getBigDecimal("salario")));
        }
        return lista;
    }

    public boolean actualizar(int id,String nombre,String documento,String rol,String correo,java.math.BigDecimal salario) throws SQLException {
        String sql="UPDATE empleados SET nombre=?,documento=?,rol=?,correo=?,salario=? WHERE id=? AND activo=TRUE";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,nombre);ps.setString(2,documento);ps.setString(3,rol);ps.setString(4,correo);ps.setBigDecimal(5,salario);ps.setInt(6,id);
            return ps.executeUpdate()>0;
        }
    }

    public boolean desactivar(int id) throws SQLException {
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement("UPDATE empleados SET activo=FALSE WHERE id=? AND activo=TRUE")) {
            ps.setInt(1,id);return ps.executeUpdate()>0;
        }
    }
}
