package com.mycompany.proyectok4juanllgos.modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public class Prestamo {
    public enum Estado { PENDIENTE, PAGADO }

    private final int id;
    private final int clienteId;
    private final int empleadoId;
    private final int cuotas;
    private final BigDecimal capital;
    /** Tasa mensual expresada como fracción: 0.02 equivale al 2 %. */
    private final BigDecimal tasaMensual;
    private final BigDecimal montoTotal;
    private final BigDecimal cuotaMensual;
    private BigDecimal saldoPendiente;
    private final LocalDate fechaInicio;
    private final LocalDate fechaVencimiento;
    private Estado estado;

    public Prestamo(int id, int clienteId, int empleadoId, BigDecimal capital,
                    BigDecimal tasaMensual, int cuotas, LocalDate inicio, LocalDate vencimiento) {
        this.id = id;
        this.clienteId = clienteId;
        this.empleadoId = empleadoId;
        this.capital = capital;
        this.tasaMensual = tasaMensual;
        this.cuotas = cuotas;
        this.fechaInicio = inicio;
        this.fechaVencimiento = vencimiento;
        this.cuotaMensual = CalculoPrestamo.calcularCuotaMensual(capital, tasaMensual, cuotas);
        this.montoTotal = cuotaMensual.multiply(BigDecimal.valueOf(cuotas)).setScale(2, RoundingMode.HALF_UP);
        this.saldoPendiente = montoTotal;
        this.estado = Estado.PENDIENTE;
    }

    public void aplicarAbono(BigDecimal abono) {
        if (abono == null || abono.signum() <= 0 || abono.compareTo(saldoPendiente) > 0) {
            throw new IllegalArgumentException("Abono inválido respecto al saldo pendiente.");
        }
        saldoPendiente = saldoPendiente.subtract(abono).setScale(2, RoundingMode.HALF_UP);
        if (saldoPendiente.signum() == 0) {
            estado = Estado.PAGADO;
        }
    }

    public int getId() { return id; }
    public int getClienteId() { return clienteId; }
    public int getEmpleadoId() { return empleadoId; }
    public int getCuotas() { return cuotas; }
    public BigDecimal getCapital() { return capital; }
    public BigDecimal getTasaMensual() { return tasaMensual; }
    public BigDecimal getMontoTotal() { return montoTotal; }
    public BigDecimal getCuotaMensual() { return cuotaMensual; }
    public BigDecimal getSaldoPendiente() { return saldoPendiente; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public Estado getEstado() { return estado; }
}
