package com.mycompany.proyectok4juanllgos.persistencia;

import com.mycompany.proyectok4juanllgos.modelo.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Acceso exclusivo a la tabla clientes. */
public class ClienteDAO {
    public int guardar(Cliente cliente, int contrasena) throws SQLException {
        String sql = "INSERT INTO clientes(nombre,documento,correo,telefono,contrasena) VALUES(?,?,?,?,?)";
        try (Connection c=ConexionBD.obtener(); PreparedStatement ps=c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre()); ps.setString(2, cliente.getDocumento());
            ps.setString(3, cliente.getCorreo()); ps.setString(4, cliente.getTelefono()); ps.setInt(5, contrasena);
            ps.executeUpdate();
            try (ResultSet rs=ps.getGeneratedKeys()) { if(rs.next()) return rs.getInt(1); }
        }
        return -1;
    }

    public List<Cliente> listar() throws SQLException {
        List<Cliente> lista=new ArrayList<>();
        String sql="SELECT id,nombre,telefono,documento,correo FROM clientes WHERE activo=TRUE ORDER BY nombre";
        try(Connection c=ConexionBD.obtener(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()) {
            while(rs.next()) lista.add(new Cliente(rs.getInt("id"),rs.getString("nombre"),rs.getString("telefono"),rs.getString("documento"),rs.getString("correo")));
        }
        return lista;
    }

    public boolean actualizar(int id, String nombre, String documento, String correo, String telefono) throws SQLException {
        String sql="UPDATE clientes SET nombre=?,documento=?,correo=?,telefono=? WHERE id=? AND activo=TRUE";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,nombre);ps.setString(2,documento);ps.setString(3,correo);ps.setString(4,telefono);ps.setInt(5,id);
            return ps.executeUpdate()>0;
        }
    }

    public boolean desactivar(int id) throws SQLException {
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement("UPDATE clientes SET activo=FALSE WHERE id=? AND activo=TRUE")) {
            ps.setInt(1,id); return ps.executeUpdate()>0;
        }
    }
}
