package com.mycompany.proyectok4juanllgos.modelo;

import java.math.BigDecimal;

public class Empleado extends Persona {
    private String documento, rol, correo;
    private BigDecimal salario;
    public Empleado(int id,String nombre,String telefono,String documento,String rol,String correo,BigDecimal salario){
        super(id,nombre,telefono);this.documento=documento;this.rol=rol;this.correo=correo;this.salario=salario;
    }
    public String getDocumento(){return documento;} public void setDocumento(String v){documento=v;}
    public String getRol(){return rol;} public void setRol(String v){rol=v;}
    public String getCorreo(){return correo;} public void setCorreo(String v){correo=v;}
    public BigDecimal getSalario(){return salario;} public void setSalario(BigDecimal v){salario=v;}
    @Override public String mostrarRol(){return rol;}
}
