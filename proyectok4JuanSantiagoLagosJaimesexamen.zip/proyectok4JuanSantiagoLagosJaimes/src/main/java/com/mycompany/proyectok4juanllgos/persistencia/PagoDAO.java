package com.mycompany.proyectok4juanllgos.persistencia;

import com.mycompany.proyectok4juanllgos.modelo.CalculoPrestamo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;

/** Registra abonos y calcula el saldo con la misma fórmula del modelo Prestamo. */
public class PagoDAO {
    public void registrar(int prestamoId, BigDecimal monto, Date fecha) throws SQLException {
        if (monto == null || monto.signum() <= 0) {
            throw new IllegalArgumentException("El abono debe ser mayor que cero.");
        }
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha del pago es obligatoria.");
        }

        try (Connection c = ConexionBD.obtener()) {
            c.setAutoCommit(false);
            try {
                BigDecimal capital;
                BigDecimal interesPorcentaje;
                int cuotas;

                // Bloquea la fila del préstamo para impedir dos abonos simultáneos inconsistentes.
                String sqlPrestamo = "SELECT monto, interes, cuotas, estado FROM prestamos WHERE id = ? FOR UPDATE";
                try (PreparedStatement q = c.prepareStatement(sqlPrestamo)) {
                    q.setInt(1, prestamoId);
                    try (ResultSet r = q.executeQuery()) {
                        if (!r.next()) {
                            throw new SQLException("El préstamo indicado no existe.");
                        }
                        if (!"PENDIENTE".equalsIgnoreCase(r.getString("estado"))) {
                            throw new SQLException("El préstamo ya está pagado o no está pendiente.");
                        }
                        capital = r.getBigDecimal("monto");
                        interesPorcentaje = r.getBigDecimal("interes");
                        cuotas = r.getInt("cuotas");
                    }
                }

                BigDecimal totalPagado;
                try (PreparedStatement q = c.prepareStatement(
                        "SELECT COALESCE(SUM(monto), 0) AS abonado FROM pagos WHERE prestamo_id = ?")) {
                    q.setInt(1, prestamoId);
                    try (ResultSet r = q.executeQuery()) {
                        r.next();
                        totalPagado = r.getBigDecimal("abonado");
                    }
                }

                BigDecimal tasaMensual = CalculoPrestamo.convertirPorcentajeAFraccion(interesPorcentaje);
                BigDecimal saldo = CalculoPrestamo.calcularSaldo(capital, tasaMensual, cuotas, totalPagado);
                if (saldo.signum() <= 0) {
                    throw new SQLException("El préstamo no tiene saldo pendiente. Verifica su estado.");
                }
                if (monto.compareTo(saldo) > 0) {
                    throw new IllegalArgumentException("El abono excede el saldo pendiente ($" + saldo + ").");
                }

                try (PreparedStatement q = c.prepareStatement(
                        "INSERT INTO pagos(prestamo_id, fecha_pago, monto) VALUES (?, ?, ?)")) {
                    q.setInt(1, prestamoId);
                    q.setDate(2, fecha);
                    q.setBigDecimal(3, monto.setScale(2, java.math.RoundingMode.HALF_UP));
                    q.executeUpdate();
                }

                BigDecimal nuevoSaldo = saldo.subtract(monto).setScale(2, java.math.RoundingMode.HALF_UP);
                if (nuevoSaldo.signum() == 0) {
                    try (PreparedStatement q = c.prepareStatement(
                            "UPDATE prestamos SET estado = 'PAGADO' WHERE id = ?")) {
                        q.setInt(1, prestamoId);
                        q.executeUpdate();
                    }
                }
                c.commit();
            } catch (Exception e) {
                c.rollback();
                if (e instanceof SQLException) throw (SQLException) e;
                if (e instanceof RuntimeException) throw (RuntimeException) e;
                throw new SQLException("No se pudo registrar el pago.", e);
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    /** Consulta el histórico de pagos de un préstamo o de toda la cartera. */
    public java.util.List<java.util.Map<String,Object>> historico(Integer prestamoId) throws SQLException {
        java.util.List<java.util.Map<String,Object>> pagos = new java.util.ArrayList<>();
        String sql = "SELECT id,prestamo_id,fecha_pago,monto FROM pagos" +
                (prestamoId == null ? "" : " WHERE prestamo_id=?") + " ORDER BY fecha_pago,id";
        try (Connection c=ConexionBD.obtener(); PreparedStatement ps=c.prepareStatement(sql)) {
            if (prestamoId != null) ps.setInt(1, prestamoId);
            try (ResultSet rs=ps.executeQuery()) {
                while (rs.next()) {
                    java.util.Map<String,Object> pago=new java.util.LinkedHashMap<>();
                    pago.put("id",rs.getInt("id")); pago.put("prestamo_id",rs.getInt("prestamo_id"));
                    pago.put("fecha_pago",rs.getDate("fecha_pago").toLocalDate()); pago.put("monto",rs.getBigDecimal("monto"));
                    pagos.add(pago);
                }
            }
        }
        return pagos;
    }

}
