package com.mycompany.proyectok4juanllgos.persistencia;
import java.sql.*;import java.util.*;
/** DAO legado adaptado al esquema SQL proporcionado. */
@Deprecated
public class PrestamoDAO {
 public boolean registrarPrestamo(double monto,double interesPorcentaje,int clienteId,int empleadoId,int cuotas,java.sql.Date fechaInicio)throws SQLException {
  String sql="INSERT INTO prestamos(monto,interes,cliente_id,empleado_id,cuotas,fecha_inicio,estado) VALUES(?,?,?,?,?,?,?)";
  try(Connection conn=ConexionBD.obtener();PreparedStatement ps=conn.prepareStatement(sql)){
   ps.setBigDecimal(1,java.math.BigDecimal.valueOf(monto));ps.setBigDecimal(2,java.math.BigDecimal.valueOf(interesPorcentaje));ps.setInt(3,clienteId);ps.setInt(4,empleadoId);ps.setInt(5,cuotas);ps.setDate(6,fechaInicio);ps.setString(7,"PENDIENTE");return ps.executeUpdate()>0;
  }
 }
 public List<String> listarPrestamos()throws SQLException {
  List<String> lista=new ArrayList<>();String sql="SELECT id,monto,interes,cliente_id,empleado_id,cuotas,fecha_inicio,estado FROM prestamos ORDER BY id";
  try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql);ResultSet rs=ps.executeQuery()){
   while(rs.next())lista.add(String.format("ID: %d | Monto: %.2f | Interés: %.2f%% | Cliente ID: %d | Empleado ID: %d | Cuotas: %d | Inicio: %s | Estado: %s",rs.getInt("id"),rs.getBigDecimal("monto"),rs.getBigDecimal("interes"),rs.getInt("cliente_id"),rs.getInt("empleado_id"),rs.getInt("cuotas"),rs.getDate("fecha_inicio"),rs.getString("estado")));
  }return lista;
 }
}
