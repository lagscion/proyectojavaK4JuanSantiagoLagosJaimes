package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.modelo.Empleado;
import com.mycompany.proyectok4juanllgos.persistencia.EmpleadoDAO;
import java.sql.SQLException;
import java.util.List;

/** Reglas de aplicación para empleados; no contiene SQL. */
public class EmpleadoServicio {
    private final EmpleadoDAO dao;
    public EmpleadoServicio(){this(new EmpleadoDAO());}
    public EmpleadoServicio(EmpleadoDAO dao){this.dao=dao;}
    public int registrar(Empleado empleado,int contrasena)throws SQLException{
        if(empleado==null || empleado.getNombre()==null || empleado.getNombre().isBlank()) throw new IllegalArgumentException("El nombre es obligatorio.");
        if(empleado.getSalario()==null||empleado.getSalario().signum()<0)throw new IllegalArgumentException("El salario no puede ser negativo.");
        if(contrasena<0||contrasena>99999)throw new IllegalArgumentException("La contraseña debe tener entre 1 y 5 dígitos.");
        return dao.guardar(empleado,contrasena);
    }
    public List<Empleado> listar()throws SQLException{return dao.listar();}
    public boolean actualizar(int id,String nombre,String documento,String rol,String correo,java.math.BigDecimal salario)throws SQLException{return dao.actualizar(id,nombre,documento,rol,correo,salario);}
    public boolean desactivar(int id)throws SQLException{return dao.desactivar(id);}
}
