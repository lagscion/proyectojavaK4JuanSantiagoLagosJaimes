package com.mycompany.proyectok4juanllgos.modelo;

import com.mycompany.proyectok4juanllgos.persistencia.dbConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Deprecated
public class prestamos {
    public static void consultarPrestamosCliente(int clienteId) {
        String sql = "SELECT p.id, e.nombre AS empleado, p.monto, p.interes, p.cuotas, "
                   + "p.fecha_inicio, p.estado, p.total_pagar, "
                   + "ROUND(p.total_pagar / p.cuotas, 2) AS cuota_mensual, "
                   + "COALESCE(SUM(pg.monto), 0) AS pagado, "
                   + "ROUND(p.total_pagar - COALESCE(SUM(pg.monto), 0), 2) AS saldo_pendiente "
                   + "FROM (SELECT pr.*, CASE WHEN pr.interes = 0 "
                   + "THEN ROUND(pr.monto / pr.cuotas, 2) * pr.cuotas "
                   + "ELSE ROUND((pr.monto * (pr.interes / 100)) / "
                   + "(1 - POWER(1 + (pr.interes / 100), -pr.cuotas)), 2) * pr.cuotas END AS total_pagar "
                   + "FROM prestamos pr) p "
                   + "JOIN empleados e ON e.id = p.empleado_id "
                   + "LEFT JOIN pagos pg ON pg.prestamo_id = p.id "
                   + "WHERE p.cliente_id = ? "
                   + "GROUP BY p.id, e.nombre, p.monto, p.interes, p.cuotas, p.fecha_inicio, p.estado, p.total_pagar "
                   + "ORDER BY p.fecha_inicio DESC";
        listar(sql, clienteId, "Asesor", "empleado");
    }

    

    // Para el empleado: los préstamos que gestiona (solo de clientes activos)
    public static void consultarPrestamosEmpleado(int empleadoId) {
        String sql = "SELECT p.id, c.nombre AS cliente, p.monto, p.interes, p.cuotas, "
                   + "p.fecha_inicio, p.estado, p.total_pagar, "
                   + "ROUND(p.total_pagar / p.cuotas, 2) AS cuota_mensual, "
                   + "COALESCE(SUM(pg.monto), 0) AS pagado, "
                   + "ROUND(p.total_pagar - COALESCE(SUM(pg.monto), 0), 2) AS saldo_pendiente "
                   + "FROM (SELECT pr.*, CASE WHEN pr.interes = 0 "
                   + "THEN ROUND(pr.monto / pr.cuotas, 2) * pr.cuotas "
                   + "ELSE ROUND((pr.monto * (pr.interes / 100)) / "
                   + "(1 - POWER(1 + (pr.interes / 100), -pr.cuotas)), 2) * pr.cuotas END AS total_pagar "
                   + "FROM prestamos pr) p "
                   + "JOIN clientes c ON c.id = p.cliente_id AND c.activo = TRUE "
                   + "LEFT JOIN pagos pg ON pg.prestamo_id = p.id "
                   + "WHERE p.empleado_id = ? "
                   + "GROUP BY p.id, c.nombre, p.monto, p.interes, p.cuotas, p.fecha_inicio, p.estado, p.total_pagar "
                   + "ORDER BY p.fecha_inicio DESC";
        listar(sql, empleadoId, "Cliente", "cliente");
    }

    // Ejecuta la consulta y muestra los resultados
    public static void listar(String sql, int id, String etiqueta, String columna) {
        dbConnection dbc = new dbConnection();

        try (Connection coneccion = dbc.conectar();
             PreparedStatement pstmt = coneccion.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                int total = 0;

                while (rs.next()) {
                    total++;
                    BigDecimal monto = rs.getBigDecimal("monto");
                    BigDecimal pagado = rs.getBigDecimal("pagado");

                    System.out.println("\n--- PRÉSTAMO #" + rs.getInt("id") + " ---");
                    System.out.println(etiqueta + ": " + rs.getString(columna));
                    System.out.println("Capital: $" + monto.toPlainString());
                    System.out.println("Interés mensual: " + rs.getBigDecimal("interes") + "%");
                    System.out.println("Cuotas: " + rs.getInt("cuotas"));
                    System.out.println("Cuota mensual: $" + rs.getBigDecimal("cuota_mensual"));
                    System.out.println("Total a pagar: $" + rs.getBigDecimal("total_pagar"));
                    System.out.println("Fecha de inicio: " + rs.getDate("fecha_inicio"));
                    System.out.println("Estado: " + rs.getString("estado"));
                    System.out.println("Total pagado: $" + pagado.toPlainString());
                    System.out.println("Saldo pendiente: $" + rs.getBigDecimal("saldo_pendiente"));
                }

                if (total == 0) {
                    System.out.println("\nNo hay préstamos relacionados.");
                } else {
                    System.out.println("\nTotal de préstamos: " + total);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        }
    }

    
}