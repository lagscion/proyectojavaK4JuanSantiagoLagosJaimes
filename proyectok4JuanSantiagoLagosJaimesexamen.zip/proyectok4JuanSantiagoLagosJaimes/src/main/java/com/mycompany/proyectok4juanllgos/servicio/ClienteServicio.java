package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.modelo.Cliente;
import com.mycompany.proyectok4juanllgos.persistencia.ClienteDAO;
import java.sql.SQLException;
import java.util.List;

/** Reglas de aplicación para clientes; no contiene SQL. */
public class ClienteServicio {
    private final ClienteDAO dao;
    public ClienteServicio(){this(new ClienteDAO());}
    public ClienteServicio(ClienteDAO dao){this.dao=dao;}
    public int registrar(Cliente cliente,int contrasena)throws SQLException{
        if(cliente==null || cliente.getNombre()==null || cliente.getNombre().isBlank()) throw new IllegalArgumentException("El nombre es obligatorio.");
        validarPin(contrasena); return dao.guardar(cliente,contrasena);
    }
    public List<Cliente> listar()throws SQLException{return dao.listar();}
    public boolean actualizar(int id,String nombre,String documento,String correo,String telefono)throws SQLException{return dao.actualizar(id,nombre,documento,correo,telefono);}
    public boolean desactivar(int id)throws SQLException{return dao.desactivar(id);}
    private void validarPin(int pin){if(pin<0||pin>99999)throw new IllegalArgumentException("La contraseña debe tener entre 1 y 5 dígitos.");}
}
