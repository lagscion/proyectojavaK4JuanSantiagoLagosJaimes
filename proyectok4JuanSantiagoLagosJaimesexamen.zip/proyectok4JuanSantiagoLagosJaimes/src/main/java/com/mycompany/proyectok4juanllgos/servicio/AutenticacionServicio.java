package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.persistencia.AutenticacionDAO;
import java.sql.SQLException;

/** Valida credenciales y delega su consulta al DAO. */
public class AutenticacionServicio {
    public static class Sesion {
        public final int id;
        public final String rol;
        public final boolean permisoModificacion;
        public Sesion(int id,String rol,boolean permisoModificacion){
            this.id=id;this.rol=rol;this.permisoModificacion=permisoModificacion;
        }
    }
    private final AutenticacionDAO dao;
    public AutenticacionServicio(){this(new AutenticacionDAO());}
    public AutenticacionServicio(AutenticacionDAO dao){this.dao=dao;}
    public Sesion autenticar(String usuario,String password)throws SQLException{
        if(usuario==null||usuario.isBlank()||password==null||!password.matches("\\d{1,5}"))return null;
        AutenticacionDAO.DatosSesion datos=dao.autenticar(usuario.trim(),Integer.parseInt(password));
        return datos==null?null:new Sesion(datos.id,datos.rol,datos.permisoModificacion);
    }
}
