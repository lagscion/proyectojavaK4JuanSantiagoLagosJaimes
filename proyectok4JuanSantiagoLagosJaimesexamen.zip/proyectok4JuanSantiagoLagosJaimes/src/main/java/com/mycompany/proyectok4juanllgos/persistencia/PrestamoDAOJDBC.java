package com.mycompany.proyectok4juanllgos.persistencia;

import com.mycompany.proyectok4juanllgos.modelo.Prestamo;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

/** DAO JDBC para préstamos, compatible con el esquema MySQL del proyecto. */
public class PrestamoDAOJDBC {
    private static final String SELECT_RESUMEN =
        "SELECT p.id,p.cliente_id,p.empleado_id,p.monto,p.interes,p.cuotas,p.fecha_inicio,p.estado,"+
        "DATE_ADD(p.fecha_inicio, INTERVAL p.cuotas MONTH) AS fecha_vencimiento,"+
        "CASE WHEN p.interes=0 THEN ROUND(p.monto/p.cuotas,2)*p.cuotas " +
        "ELSE ROUND((p.monto*(p.interes/100))/(1-POWER(1+(p.interes/100),-p.cuotas)),2)*p.cuotas END AS total_pagar,"+
        "(SELECT COALESCE(SUM(pg.monto),0) FROM pagos pg WHERE pg.prestamo_id=p.id) AS total_pagado " +
        "FROM prestamos p ";

    public int guardar(Prestamo p) throws SQLException {
        String sql="INSERT INTO prestamos(cliente_id,empleado_id,monto,interes,cuotas,fecha_inicio,estado) VALUES(?,?,?,?,?,?,?)";
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1,p.getClienteId());ps.setInt(2,p.getEmpleadoId());ps.setBigDecimal(3,p.getCapital());
            ps.setBigDecimal(4,p.getTasaMensual().multiply(new BigDecimal("100")).setScale(2,java.math.RoundingMode.HALF_UP));
            ps.setInt(5,p.getCuotas());ps.setDate(6,java.sql.Date.valueOf(p.getFechaInicio()));ps.setString(7,"PENDIENTE");ps.executeUpdate();
            try(ResultSet rs=ps.getGeneratedKeys()){if(rs.next())return rs.getInt(1);}
        }
        return -1;
    }

    public List<Map<String,Object>> listarPorCliente(int clienteId) throws SQLException {
        return consultar(SELECT_RESUMEN+"WHERE p.cliente_id=? ORDER BY p.fecha_inicio DESC",clienteId);
    }
     
    public List<Map<String,Object>> listarPorEmpleado(int empleadoId) throws SQLException {
        return consultar(SELECT_RESUMEN+"WHERE p.empleado_id=? ORDER BY p.fecha_inicio DESC",empleadoId);
    }

    /** Retorna todos los préstamos, incluidos los pagados, para construir reportes. */
    public List<Map<String,Object>> listarTodos() throws SQLException {
        return consultar(SELECT_RESUMEN+"ORDER BY p.fecha_inicio DESC");
    }

    /** Compatibilidad con el servicio de reportes: solo préstamos pendientes. */
    public List<Map<String,Object>> activos() throws SQLException {
        return consultar(SELECT_RESUMEN+"WHERE p.estado='PENDIENTE' ORDER BY p.fecha_inicio");
    }
    public List<Map<String,Object>> filtrarPrestamosVencidos() throws SQLException {
        return consultar(SELECT_RESUMEN+"WHERE p.estado='PENDIENTE' and p.fecha_fin <  CURRENT_DATE()");
    }

    public List<Map<String,Object>> consultar(String sql,Object... parametros) throws SQLException {
        List<Map<String,Object>> lista=new ArrayList<>();
        try(Connection c=ConexionBD.obtener();PreparedStatement ps=c.prepareStatement(sql)) {
            for(int i=0;i<parametros.length;i++) ps.setObject(i+1,parametros[i]);
            try(ResultSet rs=ps.executeQuery()) {
                while(rs.next()) {
                    BigDecimal total=rs.getBigDecimal("total_pagar");
                    BigDecimal pagado=rs.getBigDecimal("total_pagado");
                    BigDecimal saldo=total.subtract(pagado).max(BigDecimal.ZERO).setScale(2,java.math.RoundingMode.HALF_UP);
                    Map<String,Object> m=new LinkedHashMap<>();
                    m.put("id",rs.getInt("id"));m.put("cliente_id",rs.getInt("cliente_id"));m.put("empleado_id",rs.getInt("empleado_id"));
                    m.put("capital",rs.getBigDecimal("monto"));m.put("interes",rs.getBigDecimal("interes"));m.put("cuotas",rs.getInt("cuotas"));
                    m.put("fecha_inicio",rs.getDate("fecha_inicio").toLocalDate());m.put("fecha_vencimiento",rs.getDate("fecha_vencimiento").toLocalDate());
                    m.put("estado",rs.getString("estado"));m.put("total",total);m.put("total_pagado",pagado);m.put("cuota_mensual",total.divide(BigDecimal.valueOf(rs.getInt("cuotas")),2,java.math.RoundingMode.HALF_UP));
                    m.put("saldo",saldo);m.put("saldo_pendiente",saldo);m.put("vencido","PENDIENTE".equalsIgnoreCase(rs.getString("estado")) && rs.getDate("fecha_vencimiento").toLocalDate().isBefore(java.time.LocalDate.now()) && saldo.signum()>0);
                    lista.add(m);
                }
            }
        }
        return lista;
    }
    
}
