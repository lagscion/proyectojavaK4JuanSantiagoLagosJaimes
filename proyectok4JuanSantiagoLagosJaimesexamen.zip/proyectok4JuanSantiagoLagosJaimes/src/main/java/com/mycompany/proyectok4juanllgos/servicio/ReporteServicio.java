package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.persistencia.PrestamoDAOJDBC;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/** Construye reportes a partir de datos del DAO usando Lambda y Stream API. */
public class ReporteServicio {
    private final PrestamoDAOJDBC prestamoDAO;
    public ReporteServicio(){this(new PrestamoDAOJDBC());}
    public ReporteServicio(PrestamoDAOJDBC dao){this.prestamoDAO=dao;}

    public List<Map<String,Object>> prestamosActivos() throws SQLException {
        return prestamoDAO.listarTodos().stream()
                .filter(p -> "PENDIENTE".equals(p.get("estado")) && ((java.math.BigDecimal)p.get("saldo_pendiente")).signum()>0)
                .collect(Collectors.toList());
    }

    public List<Map<String,Object>> prestamosVencidos(LocalDate hoy) throws SQLException {
        return prestamosActivos().stream()
                .filter(p -> ((LocalDate)p.get("fecha_vencimiento")).isBefore(hoy))
                .collect(Collectors.toList());
    }

    public List<Integer> clientesMorosos(LocalDate hoy) throws SQLException {
        return prestamosVencidos(hoy).stream()
                .map(p -> (Integer)p.get("cliente_id"))
                .distinct().sorted().collect(Collectors.toList());
    }
}
