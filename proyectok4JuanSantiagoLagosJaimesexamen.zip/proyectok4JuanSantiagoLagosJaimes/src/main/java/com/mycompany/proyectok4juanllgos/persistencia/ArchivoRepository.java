package com.mycompany.proyectok4juanllgos.persistencia;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class ArchivoRepository {
    private final Path dir;
    public ArchivoRepository(Path dir){this.dir=dir;}
    public void guardar(String archivo, Collection<String> registros) throws IOException {
        Files.createDirectories(dir);
        Files.write(dir.resolve(archivo),registros,java.nio.charset.StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,StandardOpenOption.APPEND);
    }
    public List<String> leer(String archivo) throws IOException {
        Path p=dir.resolve(archivo); if(!Files.exists(p))return new ArrayList<>();
        return Files.readAllLines(p,java.nio.charset.StandardCharsets.UTF_8);
    }
}
