package com.mycompany.proyectok4juanllgos.servicio;

import com.mycompany.proyectok4juanllgos.modelo.Prestamo;
import com.mycompany.proyectok4juanllgos.persistencia.PrestamoDAOJDBC;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/** Orquesta creación y consulta de préstamos. */
public class PrestamoServicio {
    private final PrestamoDAOJDBC dao;
    public PrestamoServicio(){this(new PrestamoDAOJDBC());}
    public PrestamoServicio(PrestamoDAOJDBC dao){this.dao=dao;}
    public int crear(Prestamo prestamo)throws SQLException{
        if(prestamo==null)throw new IllegalArgumentException("El préstamo es obligatorio.");
        return dao.guardar(prestamo);
    }
    public List<Map<String,Object>> porCliente(int id)throws SQLException{return dao.listarPorCliente(id);}
    public List<Map<String,Object>> porEmpleado(int id)throws SQLException{return dao.listarPorEmpleado(id);}
    public List<Map<String,Object>> todos()throws SQLException{return dao.listarTodos();}
    public List<Map<String,Object>> filtrarPrestamosVencidos()throws SQLException{return dao.listarTodos();}
    
}
