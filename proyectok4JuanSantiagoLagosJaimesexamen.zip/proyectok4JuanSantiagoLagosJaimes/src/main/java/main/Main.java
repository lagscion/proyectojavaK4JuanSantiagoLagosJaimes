package main;

import com.mycompany.proyectok4juanllgos.modelo.Cliente;
import com.mycompany.proyectok4juanllgos.modelo.Empleado;
import com.mycompany.proyectok4juanllgos.modelo.Prestamo;
import com.mycompany.proyectok4juanllgos.servicio.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Punto de entrada. La interfaz solo llama servicios; nunca ejecuta SQL. */
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final AutenticacionServicio AUTENTICACION = new AutenticacionServicio();
    private static final ClienteServicio CLIENTES = new ClienteServicio();
    private static final EmpleadoServicio EMPLEADOS = new EmpleadoServicio();
    private static final PrestamoServicio PRESTAMOS = new PrestamoServicio();
    private static final PagoServicio PAGOS = new PagoServicio();
    private static final ReporteServicio REPORTES = new ReporteServicio();

    public static void main(String[] args) {
        boolean aplicacionActiva = true;
        while (aplicacionActiva) {
            AutenticacionServicio.Sesion sesion = iniciarSesion();
            if (sesion == null) break;
            aplicacionActiva = ejecutarMenuPrincipal(sesion);
        }
        System.out.println("Aplicación finalizada.");
    }

    private static AutenticacionServicio.Sesion iniciarSesion() {
        System.out.println("\n=== BIENVENIDO AL SISTEMA ===");
        while (true) {
            try {
                System.out.print("\nUsuario: "); String usuario = SC.nextLine().trim();
                System.out.print("Password: "); String password = SC.nextLine().trim();
                AutenticacionServicio.Sesion sesion = AUTENTICACION.autenticar(usuario,password);
                if (sesion != null) {
                    System.out.println("\n¡Acceso concedido! Bienvenido/a, " + usuario + " (" + sesion.rol + ").");
                    return sesion;
                }
                System.out.println("Acceso denegado. Usuario o contraseña incorrectos. Intente de nuevo.");
            } catch (SQLException e) {
                System.out.println("No se pudo conectar o autenticar: " + e.getMessage());
                return null;
            }
        }
    }

    private static boolean ejecutarMenuPrincipal(AutenticacionServicio.Sesion sesion) {
        boolean empleado = "empleado".equalsIgnoreCase(sesion.rol) || "admin".equalsIgnoreCase(sesion.rol)
                || "administrador".equalsIgnoreCase(sesion.rol);
        boolean permiso = sesion.permisoModificacion;
        boolean cerrarSesion = false;
        while (!cerrarSesion) {
            System.out.println("\n--- MENÚ PRINCIPAL (" + sesion.rol.toUpperCase() + ") ---");
            if (empleado) {
                System.out.println("1. Registrar empleado");
                System.out.println("2. Consultar empleados");
                System.out.println("3. Consultar préstamos relacionados");
                if (permiso) {
                    System.out.println("4. Actualizar empleado");
                    System.out.println("5. Desactivar empleado");
                    System.out.println("6. Crear préstamo");
                    System.out.println("7. Registrar abono");
                    System.out.println("8. Histórico de pagos");
                    System.out.println("9. Reportes de cartera");
                    System.out.println("10. gestor de prestamos");
                    System.out.println("11. Cerrar sesión");
                } else System.out.println("4. Cerrar sesión");
            } else {
                System.out.println("1. Registrar cliente");
                System.out.println("2. Listar clientes");
                System.out.println("3. Consultar mis préstamos");
                if (permiso) {
                    System.out.println("4. Actualizar cliente");
                    System.out.println("5. Desactivar cliente");
                    System.out.println("6. Cerrar sesión");
                } else System.out.println("4. Cerrar sesión");
            }
            System.out.print("Seleccione una opción: ");
            String op = SC.nextLine().trim();
            try {
                if (empleado) {
                    switch (op) {
                        case "1" -> registrarEmpleado();
                        case "2" -> listarEmpleados();
                        case "3" -> mostrarPrestamos(PRESTAMOS.porEmpleado(sesion.id), "Cliente");
                        case "4" -> { if (permiso) actualizarEmpleado(); else cerrarSesion = true; }
                        case "5" -> { if (permiso) desactivarEmpleado(); else opcionInvalida(); }
                        case "6" -> { if (permiso) crearPrestamo(sesion.id); else opcionInvalida(); }
                        case "7" -> { if (permiso) registrarAbono(); else opcionInvalida(); }
                        case "8" -> { if (permiso) mostrarHistoricoPagos(); else opcionInvalida(); }
                        case "9" -> { if (permiso) mostrarReportes(); else opcionInvalida(); }
                        case "10" -> { if (permiso) mostrarReportes(); else opcionInvalida(); }
                        case "11" -> { if (permiso) cerrarSesion = true; else opcionInvalida(); }
                        default -> opcionInvalida();
                    }
                } else {
                    switch (op) {
                        case "1" -> registrarCliente();
                        case "2" -> listarClientes();
                        case "3" -> mostrarPrestamos(PRESTAMOS.porCliente(sesion.id), "Asesor");
                        case "4" -> { if (permiso) actualizarCliente(); else cerrarSesion = true; }
                        case "5" -> { if (permiso) desactivarCliente(); else opcionInvalida(); }
                        case "6" -> { if (permiso) cerrarSesion = true; else opcionInvalida(); }
                        default -> opcionInvalida();
                    }
                }
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Dato inválido: " + e.getMessage());
            }
        }
        System.out.println("Cerrando sesión. Volviendo al inicio de sesión...");
        return true;
    }

    private static void registrarEmpleado() throws SQLException {
        System.out.println("\n--- REGISTRAR EMPLEADO ---");
        String nombre = leerTexto("Nombre: "); String documento = leerTexto("Documento: ");
        String rol = leerTexto("Rol: "); String correo = leerTexto("Correo: ");
        BigDecimal salario = new BigDecimal(leerTexto("Salario: "));
        int pin = Integer.parseInt(leerTexto("Contraseña numérica (máximo 5 dígitos): "));
        Empleado e = new Empleado(0,nombre,null,documento,rol,correo,salario);
        System.out.println("Empleado registrado con ID: " + EMPLEADOS.registrar(e,pin));
    }

    private static void listarEmpleados() throws SQLException {
        List<Empleado> lista = EMPLEADOS.listar();
        if (lista.isEmpty()) { System.out.println("No hay empleados activos."); return; }
        lista.forEach(e -> System.out.printf("ID: %d | %s | Documento: %s | Rol: %s | Correo: %s | Salario: $%s%n",
                e.getId(),e.getNombre(),e.getDocumento(),e.getRol(),e.getCorreo(),e.getSalario()));
    }

    private static void actualizarEmpleado() throws SQLException {
        int id = leerEntero("ID del empleado: "); String nombre=leerTexto("Nuevo nombre: ");
        String documento=leerTexto("Nuevo documento: "); String rol=leerTexto("Nuevo rol: ");
        String correo=leerTexto("Nuevo correo: "); BigDecimal salario=new BigDecimal(leerTexto("Nuevo salario: "));
        System.out.println(EMPLEADOS.actualizar(id,nombre,documento,rol,correo,salario) ? "Empleado actualizado." : "No se encontró el empleado activo.");
    }

    private static void desactivarEmpleado() throws SQLException {
        int id=leerEntero("ID del empleado a desactivar: ");
        System.out.println(EMPLEADOS.desactivar(id) ? "Empleado desactivado." : "No se encontró el empleado activo.");
    }

    private static void registrarCliente() throws SQLException {
        System.out.println("\n--- REGISTRAR CLIENTE ---");
        String nombre=leerTexto("Nombre: "); String documento=leerTexto("Documento: ");
        String correo=leerTexto("Correo: "); String telefono=leerTexto("Teléfono: ");
        int pin=Integer.parseInt(leerTexto("Contraseña numérica (máximo 5 dígitos): "));
        Cliente c=new Cliente(0,nombre,telefono,documento,correo);
        System.out.println("Cliente registrado con ID: " + CLIENTES.registrar(c,pin));
    }

    private static void listarClientes() throws SQLException {
        List<Cliente> lista=CLIENTES.listar();
        if(lista.isEmpty()){System.out.println("No hay clientes activos.");return;}
        lista.forEach(c->System.out.printf("ID: %d | %s | Documento: %s | Correo: %s | Teléfono: %s%n",
                c.getId(),c.getNombre(),c.getDocumento(),c.getCorreo(),c.getTelefono()));
    }

    private static void actualizarCliente() throws SQLException {
        int id=leerEntero("ID del cliente: ");String nombre=leerTexto("Nuevo nombre: ");
        String documento=leerTexto("Nuevo documento: ");String correo=leerTexto("Nuevo correo: ");
        String telefono=leerTexto("Nuevo teléfono: ");
        System.out.println(CLIENTES.actualizar(id,nombre,documento,correo,telefono) ? "Cliente actualizado." : "No se encontró el cliente activo.");
    }

    private static void desactivarCliente() throws SQLException {
        int id=leerEntero("ID del cliente a desactivar: ");
        System.out.println(CLIENTES.desactivar(id) ? "Cliente desactivado." : "No se encontró el cliente activo.");
    }

    private static void crearPrestamo(int empleadoId) throws SQLException {
        System.out.println("\n--- CREAR PRÉSTAMO ---");
        int clienteId=leerEntero("ID del cliente: ");
        BigDecimal capital=new BigDecimal(leerTexto("Capital del préstamo: "));
        BigDecimal porcentaje=new BigDecimal(leerTexto("Interés mensual en porcentaje (ej. 2.5): "));
        BigDecimal tasa=porcentaje.divide(new BigDecimal("100"),10,RoundingMode.HALF_UP);
        int cuotas=leerEntero("Número de cuotas: ");
        LocalDate inicio=LocalDate.parse(leerTexto("Fecha de inicio (AAAA-MM-DD): "));
        Prestamo p=new Prestamo(0,clienteId,empleadoId,capital,tasa,cuotas,inicio,inicio.plusMonths(cuotas));
        int id=PRESTAMOS.crear(p);
        System.out.printf("Préstamo registrado. ID: %d | Cuota mensual: $%s | Total: $%s | Estado: PENDIENTE%n",id,p.getCuotaMensual(),p.getMontoTotal());
    }

    private static void registrarAbono() throws SQLException {
        int id=leerEntero("ID del préstamo: ");BigDecimal monto=new BigDecimal(leerTexto("Valor del abono: "));
        PAGOS.registrar(id,monto,java.sql.Date.valueOf(LocalDate.now()));
        System.out.println("Abono registrado correctamente.");
    }

    private static void mostrarHistoricoPagos() throws SQLException {
        String entrada=leerTexto("ID del préstamo (0 para todos): ");
        Integer id=entrada.equals("0")?null:Integer.valueOf(entrada);
        List<Map<String,Object>> lista=PAGOS.historico(id);
        if(lista.isEmpty()){System.out.println("No hay pagos registrados.");return;}
        lista.forEach(p->System.out.printf("Pago #%s | Préstamo #%s | $%s | Fecha: %s%n",p.get("id"),p.get("prestamo_id"),p.get("monto"),p.get("fecha_pago")));
    }

    private static void mostrarReportes() throws SQLException {
        System.out.println("\n--- PRÉSTAMOS PENDIENTES ---");
        mostrarPrestamos(REPORTES.prestamosActivos(),"Cliente");
        System.out.println("\n--- PRÉSTAMOS VENCIDOS ---");
        List<Map<String,Object>> vencidos=REPORTES.prestamosVencidos(LocalDate.now());
        mostrarPrestamos(vencidos,"Cliente");
        System.out.println("\n--- CLIENTES MOROSOS (IDs) ---");
        List<Integer> morosos=REPORTES.clientesMorosos(LocalDate.now());
        if(morosos.isEmpty())System.out.println("No hay clientes morosos."); else morosos.forEach(id->System.out.println("Cliente #"+id));
    }

    private static void mostrarPrestamos(List<Map<String,Object>> lista,String etiquetaRelacion) {
        if(lista.isEmpty()){System.out.println("No hay préstamos para mostrar.");return;}
        for(Map<String,Object> p:lista) {
            System.out.printf("Préstamo #%s | Cliente #%s | Capital: $%s | Cuotas: %s | Cuota: $%s | Total: $%s | Pagado: $%s | Saldo: $%s | Inicio: %s | Vence: %s | Estado: %s%n",
                    p.get("id"),p.get("cliente_id"),p.get("capital"),p.get("cuotas"),p.get("cuota_mensual"),p.get("total"),p.get("total_pagado"),p.get("saldo_pendiente"),p.get("fecha_inicio"),p.get("fecha_vencimiento"),p.get("estado"));
        }
    }
    

    private static String leerTexto(String mensaje){System.out.print(mensaje);return SC.nextLine().trim();}
    private static int leerEntero(String mensaje){return Integer.parseInt(leerTexto(mensaje));}
    private static void opcionInvalida(){System.out.println("Opción no válida o no tiene permisos.");}

   
}
