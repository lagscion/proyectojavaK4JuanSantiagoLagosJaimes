-- Migración de estados de préstamos para el esquema actual.
-- Ejecutar una sola vez en la base de datos existente.
-- Mora se convierte en PENDIENTE: el vencimiento se calcula con fecha_inicio + cuotas.

-- 1. Revisar los valores actuales antes de migrar.
SELECT estado, COUNT(*) AS cantidad
FROM prestamos
GROUP BY estado;

-- 2. Normalizar los estados históricos.
UPDATE prestamos
SET estado = CASE LOWER(TRIM(estado))
    WHEN 'activo' THEN 'PENDIENTE'
    WHEN 'pendiente' THEN 'PENDIENTE'
    WHEN 'mora' THEN 'PENDIENTE'
    WHEN 'pagado' THEN 'PAGADO'
    ELSE UPPER(TRIM(estado))
END;

-- 3. Verificar que solo queden los dos estados permitidos.
SELECT estado, COUNT(*) AS cantidad
FROM prestamos
GROUP BY estado;

-- Opcional, si usas MySQL 8.0.16 o superior y la verificación anterior
-- muestra exclusivamente PENDIENTE y PAGADO, puedes activar esta restricción:
-- ALTER TABLE prestamos
-- ADD CONSTRAINT chk_prestamos_estado
-- CHECK (estado IN ('PENDIENTE', 'PAGADO'));
