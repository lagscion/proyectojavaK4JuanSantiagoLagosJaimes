CREATE DATABASE IF NOT EXISTS crediya_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crediya_db;

-- Esquema alineado con el SQL compartido por el usuario.
CREATE TABLE IF NOT EXISTS empleados (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80), documento VARCHAR(30), rol VARCHAR(30), correo VARCHAR(80),
  contrasena INT(5) UNIQUE NOT NULL,
  salario DECIMAL(10,2),
  permiso_modificacion BOOLEAN NOT NULL DEFAULT FALSE,
  activo BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80), documento VARCHAR(30), correo VARCHAR(80), telefono VARCHAR(20),
  contrasena INT(5) UNIQUE NOT NULL,
  permiso_modificacion BOOLEAN NOT NULL DEFAULT FALSE,
  activo BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS prestamos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT, empleado_id INT,
  monto DECIMAL(12,2), interes DECIMAL(5,2), cuotas INT, fecha_inicio DATE, estado VARCHAR(20),
  FOREIGN KEY (cliente_id) REFERENCES clientes(id),
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
);
CREATE TABLE IF NOT EXISTS pagos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  prestamo_id INT, fecha_pago DATE, monto DECIMAL(10,2),
  FOREIGN KEY (prestamo_id) REFERENCES prestamos(id)
);
