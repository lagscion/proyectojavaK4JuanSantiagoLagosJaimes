# CrediYa - Proyecto Java

## Normalización de estados de préstamos

El sistema utiliza ahora únicamente estos estados almacenados en `prestamos.estado`:

- `PENDIENTE`: el préstamo todavía tiene saldo por pagar.
- `PAGADO`: los pagos registrados cubrieron el total calculado.

El vencimiento no se almacena como estado. Se calcula comparando `fecha_inicio + cuotas meses` con la fecha actual, siempre que el préstamo continúe `PENDIENTE`.

### Migrar la base de datos existente

Antes de ejecutar el proyecto actualizado, abre MySQL Workbench y ejecuta una sola vez el archivo:

`src/main/resources/migracion_estados_prestamos.sql`

El script convierte `Activo`, `Mora` y `Pendiente` en `PENDIENTE`, y `Pagado` en `PAGADO`. Revisa el resultado de las consultas `SELECT` incluidas en el script antes de continuar. El script no modifica las columnas ni las relaciones de tu esquema.

### Cambios de código

- La creación de préstamos utiliza `PENDIENTE`.
- Los abonos se insertan en `pagos`; ya no reducen ni sobrescriben `prestamos.monto`.
- `PagoDAO` cambia el estado a `PAGADO` cuando el saldo llega a cero.
- Los reportes identifican vencidos mediante `DATE_ADD(fecha_inicio, INTERVAL cuotas MONTH)`.
- Se eliminó el cambio manual a `Mora` o `Pagado`, porque el estado pagado debe depender de los pagos registrados.

## Compilación

Requiere JDK 17 y Maven:

```bash
mvn clean package
```
